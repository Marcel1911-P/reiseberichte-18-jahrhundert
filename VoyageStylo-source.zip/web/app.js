"use strict";

const state = {
  corpus: [],
  result: null,
  selectedDocuments: new Set(),
  activeDocument: null,
  analyzedSignature: null,
};

const elements = {
  corpusRows: document.querySelector("#corpus-rows"),
  corpusCount: document.querySelector("#corpus-count"),
  status: document.querySelector("#status"),
  stale: document.querySelector("#results-stale"),
  analyze: document.querySelector("#analyze-button"),
  selectAll: document.querySelector("#select-all"),
  selectNone: document.querySelector("#select-none"),
  featureSet: document.querySelector("#feature-set"),
  results: document.querySelector("#results"),
  metricsRows: document.querySelector("#metrics-rows"),
  frequencies: document.querySelector("#frequencies"),
  similarityDescription: document.querySelector("#similarity-description"),
  similarityMatrix: document.querySelector("#similarity-matrix"),
  featureDetails: document.querySelector("#feature-details"),
  pcaPlot: document.querySelector("#pca-plot"),
};

const numberFormat = new Intl.NumberFormat("de-DE");
const percentFormat = new Intl.NumberFormat("de-DE", {
  style: "percent",
  maximumFractionDigits: 1,
});

function textNode(tagName, value, className) {
  const node = document.createElement(tagName);
  node.textContent = value ?? "Nicht angegeben";
  if (className) node.className = className;
  return node;
}

function setStatus(message, isError = true) {
  elements.status.textContent = message;
  elements.status.style.color = isError ? "#9b392e" : "#536254";
}

function formatMetric(value, digits = 2) {
  return new Intl.NumberFormat("de-DE", {
    maximumFractionDigits: digits,
  }).format(value ?? 0);
}

function createCorpusRow(documentInfo) {
  const row = document.createElement("tr");
  const checkboxCell = document.createElement("td");
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "row-select";
  checkbox.checked = state.selectedDocuments.has(documentInfo.file);
  checkbox.setAttribute("aria-label", `${documentInfo.title} auswählen`);
  checkbox.addEventListener("change", () => {
    if (checkbox.checked) state.selectedDocuments.add(documentInfo.file);
    else state.selectedDocuments.delete(documentInfo.file);
    updateSelectionCount();
  });
  checkboxCell.append(checkbox);

  const titleCell = document.createElement("td");
  titleCell.append(
    textNode("span", documentInfo.title, "doc-title"),
    textNode("span", documentInfo.file, "doc-file"),
  );
  const values = [
    documentInfo.author,
    documentInfo.publication_year ?? "Nicht angegeben",
    documentInfo.travel_period ?? "Nicht im Titel angegeben",
    documentInfo.destination ?? "Nicht im Titel angegeben",
    `${numberFormat.format(documentInfo.word_count)} Wörter`,
  ];
  row.append(checkboxCell, titleCell);
  for (const value of values) row.append(textNode("td", String(value)));
  return row;
}

function updateSelectionCount() {
  const count = state.selectedDocuments.size;
  elements.corpusCount.textContent = `${count} von ${state.corpus.length} ausgewählt`;
  updateStaleNotice();
}

function currentAnalysisSignature() {
  return JSON.stringify({
    documents: Array.from(state.selectedDocuments).sort(),
    featureSet: elements.featureSet.value,
  });
}

function updateStaleNotice() {
  if (!state.result || !state.analyzedSignature) return;
  const isStale = currentAnalysisSignature() !== state.analyzedSignature;
  elements.stale.classList.toggle("hidden", !isStale);
  elements.stale.textContent = isStale
    ? "Die Auswahl oder PCA-Merkmale wurden geändert. Angezeigte Ergebnisse beziehen sich noch auf die vorherige Analyse; bitte erneut analysieren."
    : "";
  elements.analyze.replaceChildren(
    document.createTextNode(isStale ? "Auswahl erneut analysieren " : "Auswahl analysieren "),
    document.createElement("span"),
  );
  elements.analyze.lastElementChild.setAttribute("aria-hidden", "true");
  elements.analyze.lastElementChild.textContent = "→";
}

function renderCorpus() {
  const fragment = document.createDocumentFragment();
  for (const item of state.corpus) fragment.append(createCorpusRow(item));
  elements.corpusRows.replaceChildren(fragment);
  updateSelectionCount();
}

async function loadCorpus() {
  try {
    const response = await fetch("/api/corpus", { headers: { Accept: "application/json" } });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Korpus konnte nicht geladen werden.");
    state.corpus = payload.documents;
    state.selectedDocuments = new Set(state.corpus.map((item) => item.file));
    renderCorpus();
  } catch (error) {
    const cell = textNode("td", error.message);
    cell.colSpan = 7;
    const row = document.createElement("tr");
    row.append(cell);
    elements.corpusRows.replaceChildren(
      row,
    );
    setStatus(error.message);
  }
}

async function analyzeSelection() {
  const documents = Array.from(state.selectedDocuments);
  if (!documents.length) {
    setStatus("Bitte wählen Sie mindestens einen Reisebericht aus.");
    return;
  }
  const requestedSignature = currentAnalysisSignature();
  elements.analyze.disabled = true;
  elements.analyze.textContent = "Analyse läuft …";
  setStatus("Die ausgewählten Texte werden lokal analysiert.", false);
  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        documents,
        feature_set: elements.featureSet.value,
      }),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Analyse fehlgeschlagen.");
    state.result = payload;
    state.analyzedSignature = requestedSignature;
    state.activeDocument = payload.documents[0]?.file ?? null;
    renderResults();
    setStatus("Analyse abgeschlossen. Texte und Ergebnisse verlassen dieses Gerät nicht.", false);
    elements.results.classList.remove("hidden");
    updateStaleNotice();
    elements.results.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    setStatus(error.message);
  } finally {
    elements.analyze.disabled = false;
    if (state.result) {
      updateStaleNotice();
    } else {
      const arrow = document.createElement("span");
      arrow.setAttribute("aria-hidden", "true");
      arrow.textContent = "→";
      elements.analyze.replaceChildren(
        document.createTextNode("Auswahl analysieren "),
        arrow,
      );
    }
  }
}

function renderMetrics() {
  const fragment = document.createDocumentFragment();
  for (const item of state.result.documents) {
    const metrics = item.metrics;
    const row = document.createElement("tr");
    row.tabIndex = 0;
    row.setAttribute("aria-selected", String(item.file === state.activeDocument));
    row.addEventListener("click", () => {
      state.activeDocument = item.file;
      renderMetrics();
      renderFrequencies();
    });
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        row.click();
      }
    });
    row.append(
      textNode("td", item.title, "doc-title"),
      textNode("td", numberFormat.format(metrics.word_count)),
      textNode("td", numberFormat.format(metrics.sentence_count)),
      textNode("td", formatMetric(metrics.average_sentence_length_words)),
      textNode("td", formatMetric(metrics.average_word_length_letters)),
      textNode("td", formatMetric(metrics.type_token_ratio, 3)),
      textNode("td", percentFormat.format(metrics.hapax_type_share)),
    );
    fragment.append(row);
  }
  elements.metricsRows.replaceChildren(fragment);
}

function renderFrequencies() {
  const item = state.result.documents.find((documentInfo) => documentInfo.file === state.activeDocument);
  if (!item) {
    elements.frequencies.replaceChildren();
    return;
  }
  const makeFrequencyCard = (title, frequencies) => {
    const card = document.createElement("article");
    card.className = "frequency-card";
    card.append(textNode("h3", title));
    const list = document.createElement("ol");
    for (const word of frequencies) {
      list.append(
        textNode(
          "li",
          `${word.word} · ${numberFormat.format(word.count)} (${percentFormat.format(word.share_of_words)})`,
        ),
      );
    }
    if (!frequencies.length) {
      list.append(textNode("li", "Keine Kandidaten erkannt."));
    }
    card.append(list);
    return card;
  };
  elements.frequencies.replaceChildren(
    makeFrequencyCard(`Häufigste Wörter · ${item.title}`, item.metrics.most_frequent_words),
    makeFrequencyCard(
      `Nomen-/Ortsnamen-Kandidaten · ${item.title}`,
      item.metrics.most_frequent_noun_candidates,
    ),
  );
}

function renderMatrix() {
  const stylometry = state.result.stylometry;
  const names = stylometry.documents;
  const similarity = stylometry[state.result.pca.feature_set].similarity_matrix;
  const labelByFile = new Map(state.result.documents.map((item) => [item.file, item.title]));
  elements.similarityDescription.textContent =
    `Cosine Similarity der ${state.result.pca.feature_set === "function_words" ? "relativen Funktionsworthäufigkeiten" : "TF-IDF-Merkmale"} für ${names.length} ausgewählte Texte.`;
  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  headRow.append(textNode("th", "Cosinusähnlichkeit"));
  for (const name of names) {
    const cell = textNode("th", labelByFile.get(name) || name);
    cell.title = name;
    headRow.append(cell);
  }
  thead.append(headRow);
  const tbody = document.createElement("tbody");
  names.forEach((name, rowIndex) => {
    const row = document.createElement("tr");
    const label = textNode("th", labelByFile.get(name) || name, "matrix-label");
    label.scope = "row";
    label.title = name;
    row.append(label);
    similarity[rowIndex].forEach((value) => {
      const cell = textNode("td", formatMetric(value, 3));
      cell.style.backgroundColor = `rgba(49, 90, 69, ${0.06 + value * 0.48})`;
      cell.style.color = value > 0.78 ? "#fff" : "#25352a";
      cell.setAttribute("aria-label", `Cosine Similarity ${formatMetric(value, 3)}`);
      row.append(cell);
    });
    tbody.append(row);
  });
  elements.similarityMatrix.replaceChildren(thead, tbody);
}

function renderFeatureDetails() {
  const cards = [];
  const featureSet = state.result.pca.feature_set;
  const vectors = state.result.stylometry[featureSet].vectors;
  for (const item of state.result.documents) {
    const features = item.stylometric_features;
    const card = document.createElement("article");
    card.className = "feature-card";
    card.append(textNode("h3", item.title));
    const distribution = features.function_word_distribution;
    if (featureSet === "tfidf") {
      const topTerms = Object.entries(vectors[item.file])
        .sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0], "de"))
        .slice(0, 8)
        .map(([term, weight]) => `${term} (${formatMetric(weight, 3)})`);
      card.append(textNode("p", `Höchste TF-IDF-Gewichte: ${topTerms.join(", ") || "keine Tokens"}`));
    } else {
      card.append(
        textNode(
          "p",
          `Funktionswörter: ${numberFormat.format(distribution.token_count)} Tokens (${percentFormat.format(distribution.share_of_words)} aller Wörter). TTR ${formatMetric(features.type_token_ratio, 3)}, durchschnittliche Satzlänge ${formatMetric(features.average_sentence_length_words)} Wörter.`,
        ),
      );
    }
    cards.push(card);
  }
  elements.featureDetails.replaceChildren(...cards);
}

function createSvgElement(name, attributes = {}) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", name);
  for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, String(value));
  return node;
}

function renderPca() {
  const pca = state.result.pca;
  if (
    pca.documents.length < 2 ||
    pca.component_count === 0 ||
    pca.explained_variance_ratio.every((ratio) => ratio === 0)
  ) {
    const message = pca.documents.length < 2
      ? "Für eine aussagefähige PCA-Projektion müssen mindestens zwei Texte ausgewählt sein."
      : "Die ausgewählten Merkmale variieren nicht; deshalb lässt sich keine aussagefähige PCA-Projektion berechnen.";
    elements.pcaPlot.replaceChildren(textNode("p", message, "pca-empty"));
    return;
  }
  const width = 1000;
  const height = 520;
  const margin = { left: 90, right: 30, top: 70, bottom: 80 };
  const coordinates = pca.documents.map((file) => pca.scores[file]);
  const xValues = coordinates.map((point) => point[0]);
  const yValues = coordinates.map((point) => point[1]);
  let xMin = Math.min(0, ...xValues);
  let xMax = Math.max(0, ...xValues);
  let yMin = Math.min(0, ...yValues);
  let yMax = Math.max(0, ...yValues);
  const xPadding = Math.max((xMax - xMin) * 0.18, 0.01);
  const yPadding = Math.max((yMax - yMin) * 0.18, 0.01);
  xMin -= xPadding; xMax += xPadding;
  yMin -= yPadding; yMax += yPadding;
  const x = (value) => margin.left + ((value - xMin) / (xMax - xMin)) * (width - margin.left - margin.right);
  const y = (value) => height - margin.bottom - ((value - yMin) / (yMax - yMin)) * (height - margin.top - margin.bottom);
  const svg = createSvgElement("svg", {
    class: "pca-svg",
    viewBox: `0 0 ${width} ${height}`,
    role: "group",
    "aria-label": "PCA-Diagramm mit zwei beschrifteten Hauptkomponenten und erklärter Varianz",
  });
  const title = createSvgElement("title");
  title.textContent = "Explorative PCA der stilometrischen Merkmale";
  svg.append(title);
  const grid = createSvgElement("g", { stroke: "#e6e8e0", "stroke-width": 1 });
  for (let index = 0; index <= 5; index += 1) {
    const fraction = index / 5;
    const gx = margin.left + fraction * (width - margin.left - margin.right);
    const gy = margin.top + fraction * (height - margin.top - margin.bottom);
    grid.append(
      createSvgElement("line", { x1: gx, x2: gx, y1: margin.top, y2: height - margin.bottom }),
      createSvgElement("line", { x1: margin.left, x2: width - margin.right, y1: gy, y2: gy }),
    );
  }
  svg.append(grid);
  svg.append(
    createSvgElement("line", { x1: margin.left, x2: width - margin.right, y1: height - margin.bottom, y2: height - margin.bottom, stroke: "#687269" }),
    createSvgElement("line", { x1: margin.left, x2: margin.left, y1: margin.top, y2: height - margin.bottom, stroke: "#687269" }),
  );
  const xAxis = createSvgElement("text", { x: width / 2, y: height - 24, "text-anchor": "middle", fill: "#36483c", "font-size": 14 });
  xAxis.textContent = `PC1 · ${percentFormat.format(pca.explained_variance_ratio[0])} erklärte Varianz`;
  const yAxis = createSvgElement("text", { x: 24, y: height / 2, "text-anchor": "middle", fill: "#36483c", "font-size": 14, transform: `rotate(-90 24 ${height / 2})` });
  yAxis.textContent = `PC2 · ${percentFormat.format(pca.explained_variance_ratio[1])} erklärte Varianz`;
  svg.append(xAxis, yAxis);
  const palette = ["#315a45", "#bd7443", "#496f9e", "#986184", "#79863c", "#b44e42"];
  pca.documents.forEach((file, index) => {
    const point = pca.scores[file];
    const item = state.result.documents.find((documentInfo) => documentInfo.file === file);
    const group = createSvgElement("g", {
      class: "pca-point",
      tabindex: 0,
      role: "button",
      "aria-pressed": state.selectedDocuments.has(file),
      "aria-label": `${item?.title ?? file}; PC1 ${formatMetric(point[0], 4)}, PC2 ${formatMetric(point[1], 4)}. Anklicken, um die Auswahl umzuschalten.`,
    });
    group.dataset.file = file;
    const tooltip = createSvgElement("title");
    tooltip.textContent = `${item?.title ?? file} · PC1 ${formatMetric(point[0], 4)} · PC2 ${formatMetric(point[1], 4)}`;
    const circle = createSvgElement("circle", {
      class: "point-dot",
      cx: x(point[0]),
      cy: y(point[1]),
      r: 7,
      fill: palette[index % palette.length],
      stroke: state.selectedDocuments.has(file) ? "#20251f" : "#fff",
      "stroke-width": state.selectedDocuments.has(file) ? 2 : 1,
    });
    const label = createSvgElement("text", {
      class: "pca-label",
      x: x(point[0]) + 11,
      y: y(point[1]) - 10,
    });
    label.textContent = item?.title ?? file;
    group.append(tooltip, circle, label);
    group.addEventListener("click", () => togglePcaSelection(file));
    group.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        togglePcaSelection(file);
      }
    });
    svg.append(group);
  });
  elements.pcaPlot.replaceChildren(svg);
}

function togglePcaSelection(file) {
  if (state.selectedDocuments.has(file)) state.selectedDocuments.delete(file);
  else state.selectedDocuments.add(file);
  renderCorpus();
  setStatus("Auswahl geändert. Starten Sie die Analyse erneut, um Vergleich und PCA zu aktualisieren.", false);
}

elements.featureSet.addEventListener("change", () => {
  setStatus("PCA-Merkmale geändert. Analysieren Sie die Auswahl erneut, um die Ergebnisse zu aktualisieren.", false);
  updateStaleNotice();
});

function renderResults() {
  renderMetrics();
  renderFrequencies();
  renderMatrix();
  renderFeatureDetails();
  renderPca();
}

elements.selectAll.addEventListener("click", () => {
  state.selectedDocuments = new Set(state.corpus.map((item) => item.file));
  renderCorpus();
});
elements.selectNone.addEventListener("click", () => {
  state.selectedDocuments.clear();
  renderCorpus();
});
elements.analyze.addEventListener("click", analyzeSelection);
loadCorpus();
