# VoyageStylo

VoyageStylo ist eine lokal laufende Webanwendung zur transparenten, explorativen Analyse deutschsprachiger Reiseberichte des 18. Jahrhunderts. Die Oberfläche nutzt die vorhandene Tokenisierung, linguistische Kennzahlen, TF-IDF-/Funktionswortvergleiche und PCA aus `src/`. Die Oberfläche implementiert keine eigene Textanalyse.

## Öffentliche Projektseite

Die statische Informationsseite ist unter [marcel1911-p.github.io/reiseberichte-18-jahrhundert](https://marcel1911-p.github.io/reiseberichte-18-jahrhundert/) veröffentlicht. Sie enthält keine OCR-Korpustexte oder Analyseergebnisse und bietet keine interaktive Analyse. Die vollständige Webanwendung muss wie unten beschrieben lokal gestartet werden. Die separate Pages-Quelle liegt in `github-pages/`; veröffentliche nicht versehentlich das gesamte VoyageStylo-Projekt als öffentliches Repository.

## Voraussetzungen

- Python 3.10 oder neuer
- Kein Paketmanager und keine zusätzlichen Python-Abhängigkeiten nötig
- Ein aktueller Browser

## Installation und Start

1. Repository lokal ablegen. Für die Standardkonfiguration müssen `data/processed/` und `data/metadata/source_manifest.json` vorhanden sein.
2. Bei Bedarf verarbeitete Korpusdateien aus den unveränderten Rohtexten erzeugen:

   ```powershell
   python src/preprocess.py
   ```

3. Den lokalen Webserver starten:

   ```powershell
   python src/web_app.py
   ```

4. Im Browser `http://127.0.0.1:8000` öffnen.
5. Gewünschte Reiseberichte über die Kontrollkästchen auswählen und **Auswahl analysieren** betätigen. In der Auswahlbox lässt sich zwischen Funktionswort- und TF-IDF-Merkmalen für die PCA wechseln. Mit `Ctrl+C` wird der Server beendet.

Alternativ lässt sich der Port anpassen:

```powershell
python src/web_app.py --port 8080
```

Der Server akzeptiert ausschliesslich Loopback-Adressen (`127.0.0.1`, `localhost`, `::1`) und ist nicht für den öffentlichen Netzwerkbetrieb vorgesehen. Texte und Analyseergebnisse werden nicht an externe Dienste übermittelt. Die Oberfläche, Schriftarten, Analyse und Grafiken werden lokal bereitgestellt.

## Oberfläche

- **Korpusübersicht:** Titel, Urheber, Publikationsjahr und Umfang der vorbereiteten Texte. Reiseziele und Reisezeiträume werden nur ausgewiesen, wenn sie im Quellentitel ausdrücklich genannt sind; fehlende Angaben werden nicht ergänzt oder erraten.
- **Linguistische Profile:** Wort- und Satzzahl, durchschnittliche Satz- und Wortlänge, Type-Token-Ratio, Hapax-Type-Anteil, häufigste Wörter und bis zu 20 heuristische Nomen-/Ortsnamen-Kandidaten samt Häufigkeit. Die Kandidatenliste ist keine sichere Wortarten- oder Eigennamenerkennung.
- **Stilometrischer Vergleich:** Cosine-Similarity-Matrix des jeweils gewählten Merkmalsblocks und getrennte stilometrische Beschreibungsmerkmale.
- **Interaktive PCA:** beschriftete Projektion der ausgewählten Texte auf PC1/PC2 samt erklärten Varianzanteilen. Ein Punkt kann angeklickt werden, um den Bericht zur nächsten Analyseauswahl hinzuzufügen oder daraus zu entfernen; anschliessend **Auswahl analysieren** erneut betätigen.

Die Voreinstellung der PCA sind relative Häufigkeiten der versionierten lokalen Funktionswortliste. Alternativ ist die TF-IDF-Repräsentation wählbar. PCA- und Ähnlichkeitsansichten sind explorative Darstellungen der ausgewählten Merkmale. Sie belegen weder wahre Autorschaft noch historische, soziale oder literarische Zusammenhänge. Details zu Annahmen und Grenzen: [docs/stylometry.md](docs/stylometry.md), [docs/pca.md](docs/pca.md) und [docs/quality_assurance.md](docs/quality_assurance.md).

## Tests

Die vollständige Testsuite einschliesslich Webserver-/API-Integrationstests lokal ausführen:

```powershell
python -m unittest discover -s tests -v
```

## Projektstruktur

- `data/raw/`: unveränderte OCR-Quelldateien.
- `data/processed/`: separat verarbeitete Analysefassungen.
- `data/metadata/source_manifest.json`: bibliografische Quellenmetadaten.
- `src/`: Vorverarbeitung, Analysefunktionen, PCA und lokaler Webserver.
- `web/`: statische, lokal ausgelieferte Oberfläche.
- `tests/`: Unit- und Integrationstests.
- `docs/`: Dokumentation zu Verarbeitung, Kennzahlen, Stilometrie und PCA.
