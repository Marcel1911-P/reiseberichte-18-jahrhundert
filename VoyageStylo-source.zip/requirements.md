# VoyageStylo Requirements

## Purpose
VoyageStylo analyzes German-language travel reports from the 18th century using stylometric features.

## Input
- Users can load multiple text files for analysis.

## Analysis
For each text, calculate at least:
- Word count
- Sentence count
- Mean sentence length
- Mean word length
- Type-token ratio (TTR)
- Most frequent words
- Function-word distribution

## Comparison and visualization
- Compare texts using their stylometric features.
- Provide a PCA visualization of the analyzed texts.

## Privacy
- Process texts locally; do not transmit text or derived corpus content to external services.

## Interface
- Provide a local web interface for uploading and analyzing multiple files, inspecting per-text metrics, comparing selected texts, and viewing PCA.
- Keep the processing local to the user's device. The implementation stack is not yet specified.

## Research integrity
- Preserve historical spelling in raw corpus files and do not silently modernize texts.
- Document all preprocessing steps and assumptions that may affect results.
- Use reproducible, transparent methods and flag uncertainty.
- Do not invent historical corpus data.
