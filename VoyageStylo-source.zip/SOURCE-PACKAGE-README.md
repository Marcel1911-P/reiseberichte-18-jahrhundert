# VoyageStylo-Quellpaket

Dieses Paket enthält die Anwendung, ihre Tests und die begleitende Dokumentation. Es enthält absichtlich **keine** Dateien aus `data/`: weder OCR-Korpusdateien noch Metadaten, vorverarbeitete Texte oder daraus erzeugte Kennzahlen und Grafiken.

## Inhalt

- `src/`: Vorverarbeitung, linguistische und stilometrische Analyse, PCA und lokaler Webserver
- `web/`: Browseroberfläche
- `tests/`: Unit- und HTTP-Integrationstests
- `docs/`: Methoden-, Korpus- und Qualitätssicherungsdokumentation
- `requirements.md`, `AGENTS.md`, `README.md`: Anforderungen und Projektinformationen

## Lokal verwenden

Voraussetzung ist Python 3.10 oder neuer. Für die Korpusübersicht und Analyse müssen Nutzende selbst UTF-8-Textdateien und ein dazu passendes Quellenmanifest in den erwarteten `data/processed/`- und `data/metadata/`-Verzeichnissen bereitstellen. Diese Dateien sind nicht im Paket enthalten. Bitte nur Texte verwenden, deren lokale Verarbeitung und gegebenenfalls Weitergabe rechtmässig ist; das Projektmanifest klärt die Weiterverbreitungsrechte nicht für alle ursprünglichen OCR-Dateien.

Mit bereitgestellten lokalen Daten kann die Anwendung aus dem Projektverzeichnis so gestartet werden:

```powershell
python src/web_app.py
```

Danach `http://127.0.0.1:8000` öffnen. Die Anwendung verarbeitet Texte lokal; GitHub Pages führt keinen Python-Server aus und stellt keine Online-Analyse bereit.

Die Testsuite wird mit folgendem Befehl ausgeführt:

```powershell
python -m unittest discover -s tests -v
```

Der Korpus-Integrationstest in `tests/test_preprocess.py` benötigt zusätzlich lokale Dateien in `data/raw/`; ohne diese Daten kann dieser Test nicht ausgeführt werden. Tests mit künstlichen Textbeispielen und der Webserver brauchen keine historischen Korpusdateien.

## Methodische Einordnung

Die Resultate sind explorative sprachliche Vergleiche. TF-IDF, Funktionswortprofile und PCA beweisen weder Autorschaft noch historische oder literarische Zusammenhänge. Details zu Vorverarbeitung, Textlängen, OCR und methodischen Grenzen stehen unter `docs/`.
