# Coding Agent Instructions

## Project
VoyageStylo analyzes German travel reports from the 18th century.

## General rules
- Explain changes before implementing complex features.
- Do not delete existing functionality.
- Write tests for analysis functions.
- Do not invent historical corpus data.
- Keep raw corpus files unchanged.
- Document assumptions.
- Use reproducible analysis.
- Prefer simple and transparent methods.
- Flag uncertainty instead of hiding it.

## Linguistic requirements
- Preserve historical German orthography in the raw corpus.
- Do not silently modernize texts.
- Document every preprocessing step.

## Privacy and analysis
- Process text locally and do not send corpus text or derived corpus content to external services.
- Keep preprocessing reproducible and explicit; record tokenization, normalization, and function-word-list decisions that affect metrics.
- Separate any transformed analysis representation from raw source text.
- Use transparent feature preparation for comparisons and PCA, and disclose limitations such as short texts or incomparable feature scales.
