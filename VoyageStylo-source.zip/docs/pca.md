# PCA-Visualisierung der stilometrischen Merkmale

## Zweck

`src/pca_visualization.py` erzeugt eine eigenständige SVG-Streugrafik, in der jeder Text als beschrifteter Punkt in den ersten beiden Hauptkomponenten dargestellt wird. Die PCA ist ausschliesslich eine explorative Projektion der gewählten sprachlichen Merkmale. Nähe in der Grafik ist kein Beweis für tatsächliche literarische oder historische Zusammenhänge und erlaubt keine Aussage über Autorschaft.

Ausführen:

```powershell
python src/pca_visualization.py
python src/pca_visualization.py --input-dir data/processed --output data/processed/stylometry_pca.svg
python src/pca_visualization.py --feature-set tfidf --output data/processed/stylometry_pca_tfidf.svg
python -m unittest discover -s tests -v
```

Die Voreinstellung schreibt `data/processed/stylometry_pca.svg`. Die Grafik ist ein lokales SVG, das sich ohne Plot-Bibliothek oder Netzwerkverbindung in Browsern und Vektorgrafikprogrammen öffnen lässt.

## Eingangsdaten

Die PCA verwendet die bereits erzeugten Dokumentvektoren aus `src/stylometry.py`, nicht Rohtext oder neu erfundene Merkmale. Standardmässig wird der Block `function_words` verwendet: die relativen Häufigkeiten der versionierten Funktionswortliste `voyagestylo-de-historical-v2`. Jede Wortzahl wird dort bereits durch die Gesamtzahl aller Tokens des Dokuments geteilt. Damit bilden längere Texte nicht allein wegen einer grösseren absoluten Tokenzahl grössere Merkmalswerte.

Mit `--feature-set tfidf` können alternativ die sparse TF-IDF-Vektoren der Stilanalyse projiziert werden. Für dieses Vokabular wird die Vereinigung aller Terme alphabetisch sortiert und in einem dichten PCA-Eingangsmatrixformat fehlende Dokument-Terme mit null ergänzt. Die beiden Merkmalsblöcke werden nicht automatisch zusammengefügt; das vermeidet eine unbegründete Blockgewichtung. Texte werden alphabetisch in der Reihenfolge geführt, die die stilometrische Analyse ausgibt.

## Zentrierung, Standardisierung und Komponenten

Die Eingabemerkmale werden pro Spalte um ihren Mittelwert zentriert, wie für PCA üblich. Es findet keine zusätzliche Standardisierung auf Einheitsvarianz statt. Bei sparsamen Funktionswortprofilen könnte Z-Standardisierung seltene Merkmale überproportional verstärken; die relativen Häufigkeiten sind bereits auf die jeweilige Textlänge bezogen. Auch TF-IDF-Vektoren sind bereits in der zugrunde liegenden Analyse je Dokument L2-normalisiert. Diese Wahl lässt die Skala der ursprünglichen stilometrischen Merkmale interpretierbar, bedeutet aber, dass Merkmale mit grösserer beobachteter Streuung mehr Einfluss auf die PCA haben.

Berechnet werden die beiden wichtigsten Hauptkomponenten. Die Implementierung nutzt den Gram-Matrix-Ansatz und einen deterministischen Jacobi-Eigenwertlöser aus der Python-Standardbibliothek. Eigenvektor-Vorzeichen werden deterministisch ausgerichtet; Werte und erklärte Varianz werden reproduzierbar ausgegeben. Bei weniger als drei Dokumenten oder rangreduzierten Daten können weniger als zwei nichttriviale Komponenten existieren; fehlende Achsen werden dann mit null Koordinaten und null erklärter Varianz dargestellt. Bei einer einzelnen Datei oder vollständig konstanten Merkmalen liegen alle Punkte im Ursprung.

Die Achsenbeschriftung zeigt den Anteil der Gesamtvarianz, der durch die jeweilige Komponente erklärt wird. Der Anteil einer Komponente ist ihr Eigenwert dividiert durch die Summe aller Eigenwerte der zentrierten Daten. Zusammen erklären PC1 und PC2 im Allgemeinen nicht die gesamte Variation; die zweidimensionale Grafik verwirft Information aus weiteren Komponenten.

## Interpretation

Punkte, die in der dargestellten Projektion nahe liegen, besitzen in den gewählten Merkmalen ähnliche Profile entlang der abgebildeten Komponenten. Weit auseinanderliegende Punkte unterscheiden sich stärker in diesen Projektionen. Die Richtung und die Achsenwerte sind mathematische Koordinaten, keine direkt benannten sprachlichen oder historischen Ursachen. Abstände in der Grafik können durch die Projektion verzerrt sein; erklärter Varianzanteil und Merkmalsblock müssen bei jeder Interpretation mitgelesen werden.

Die vollständigen Dokumentnamen stehen neben den Punkten, und die Achsentitel nennen PC1/PC2 samt erklärtem Varianzanteil. SVG-Ausgabe, alphabetische Eingabereihenfolge, feste Merkmalsreihenfolge und deterministischer Eigenwertlöser machen die Grafik reproduzierbar.

## Grenzen bei einem kleinen historischen Korpus

- Bei wenigen Dokumenten kann die PCA höchstens `n - 1` nichttriviale Komponenten bilden. Die beobachtete Verteilung einzelner Texte kann die Achsen stark bestimmen; weitere Dokumente können die Projektion deutlich verändern.
- Historische Orthographie, Genre, Thema, Übersetzung, Edition und OCR-Qualität beeinflussen die Häufigkeitsvektoren. Eine Gruppierung beweist nicht, welcher dieser Faktoren eine Ähnlichkeit verursacht.
- Kurze Texte liefern besonders volatile relative Häufigkeiten. Längennormierung entfernt den blossen Grösseneffekt der absoluten Wortzahl, aber nicht die Unsicherheit, die durch wenige Beobachtungen entsteht. Die Grafik ist kein Ersatz für vergleichbare Textumfänge oder Qualitätskontrolle.
- Die Funktionswortliste ist begrenzt und ihre Zuordnung berücksichtigt keinen Satzkontext. Bei TF-IDF können Inhaltswörter thematische Nähe abbilden.
- Nicht standardisierte Merkmale mit höherer Varianz haben mehr Gewicht. Die PCA hängt daher von der gewählten Merkmalsart und Skalierung ab; verschiedene Einstellungen sind nicht direkt austauschbar.
- Die Projektion ist explorativ, kein Signifikanztest und keine Inferenz über Autorschaft oder wahre historische, literarische beziehungsweise soziale Beziehungen.
