# Vorverarbeitung des OCR-Korpus

## Zweck und Grundsatz

`src/preprocess.py` erzeugt aus jeder UTF-8-Datei `data/raw/*.txt` eine gleichnamige Datei in `data/processed/`. Die Rohdateien werden ausschliesslich gelesen und nie als Ausgabepfad verwendet. Die Pipeline nutzt nur die Python-Standardbibliothek und ist deterministisch.

Ausfuehren:

```powershell
python src/preprocess.py
python -m unittest discover -s tests -v
```

## Verarbeitungsschritte

1. Dateien werden nach Dateiname sortiert und strikt als UTF-8 dekodiert. Bei ungueltigem UTF-8 bricht der Lauf ab, statt Zeichen still zu ersetzen.
2. CRLF- und CR-Zeilenenden werden in LF ueberfuehrt.
3. Nur klar erkannte, quellenspezifische Scan-Beigaben an Dateigrenzen werden entfernt:
   - Jagemann: der am Dateianfang stehende, englisch/deutsche Google-Books-Digitalisierungsvermerk, begrenzt durch den OCR-Anfang `Den gesamten Buch...`; ein am Dateiende stehender Stanford-Ausleihzettel wird nur ab dem `STANFORD`-Marker und bei vorhandenem `DATE DUE` entfernt.
   - Sparrman: die abschliessenden Bamberg/BSB-Katalogzeilen ab `Bamberg, Staatsbibliothek --`, nur wenn dahinter eine BVB-URN oder die verifizierte Exemplar-ID `018 14633965-001` steht. Die OCR-Form `um:nbn.de:bvb:` wird als fehlgelesene URN-Signatur erkannt.
   - Meiners: der abschliessende MDZ-Digitale-Bibliothek-Datensatz wird nur entfernt, wenn er nahe Dateiende steht und eine BVB-URN oder die verifizierte Exemplar-ID `018 80023479-001` folgt. Der Text vor `MDZ` auf derselben Zeile bleibt erhalten.
   Andere vermeintliche Stempel, Titelblaetter, Columbia-Vermerke oder OCR-Fragmente werden nicht anhand unsicherer Vermutungen entfernt.
4. Alleinstehende arabische Zahlzeilen werden nur entfernt, wenn mindestens fuenf Kandidaten in aufsteigender Folge jeweils um eins zunehmen und jeder Kandidat unmittelbar neben einer nichtleeren Zeile mit mindestens 15 Buchstaben liegt. Diese strenge Heuristik erkennt die interleavte Seitenzahlfolge im Meiners-Text. Zahlenfolgen ohne diesen Textkontext, darunter die mehrdeutige Zahlen-/OCR-Passage bei Niebuhr, bleiben erhalten.
5. Nichtleere OCR-Zeilen innerhalb eines Absatzes werden mit einem Leerzeichen zusammengefuehrt. Eine oder mehrere Leerzeilen trennen weiterhin Abschnitte; mehrere Leerzeilen werden zu einer Absatzgrenze normalisiert.
6. Das spezielle Umbruchzeichen `⸗` wird nur am Zeilenende und nur vor einem kleingeschriebenen Anschluss entfernt; beide Wortteile werden dann zusammengezogen. Das normale ASCII-Bindestrichzeichen wird nicht automatisch entfernt oder dehypheniert, weil eine echte historische Bindestrichschreibung nicht sicher von einem Zeilenumbruch unterschieden werden kann. Im Reflow bleibt es daher erhalten und es wird ein Leerzeichen gesetzt.
7. Es findet keine Unicode-Normalisierung, Rechtschreibmodernisierung, OCR-Buchstabenkorrektur, Gross-/Kleinschreibungsnormalisierung oder inhaltliche Korrektur statt. Unsichere OCR-Stellen bleiben sichtbar.

## Grenzen und Annahmen

- Das OCR-Textformat enthaelt keine verlaesslichen Seitenmarken. Die Seitenzahlregel ist deshalb bewusst eng; einzelne Seitenzahlen und unregelmaessige Folgen bleiben moeglicherweise stehen.
- Auch eine lange, interleavte Zahlenfolge koennte theoretisch eine nummerierte Liste sein. Die verwendete Mindestlaenge und der Textkontext reduzieren dieses Risiko, beweisen aber keine Seitenfunktion. Entfernte Nummern werden nicht aus den Rohdateien geloescht.
- Leerzeilen gelten als Absatzgrenzen. Falls ein OCR-Digitalisat Leerzeilen innerhalb eines gedruckten Absatzes einfuegt, bleibt dieser Abstand in der Ausgabe erhalten.
- Das Zusammenfuehren von Zeilen veraendert die Layoutstruktur, nicht die Orthographie. Bei ASCII-Bindestrichen wird absichtlich keine automatische Wortzusammenfuehrung versucht.
- Die erkannten Google-/Bibliotheksbeitraege sind quellenspezifische, sichtbare Digitalisierungsbeigaben. Aendern sich die Quelldateien oder ihre OCR-Marker, muessen Regeln und Tests neu geprueft werden.

## Tests

`tests/test_preprocess.py` prueft die Regeln mit kleinen Beispielen sowie gegen den realen Korpus. Die Integrationstests vergleichen SHA-256-Werte der Rohdateien vor und nach der Verarbeitung, pruefen eine verarbeitete Datei pro Original, vergleichen Wiederholungsläufe und kontrollieren, dass `ſ`, `daß` und `bey` im Forster-Text erhalten bleiben.