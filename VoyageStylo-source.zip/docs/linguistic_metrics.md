# Definition linguistischer Kennzahlen

## Geltungsbereich

`src/linguistic_analysis.py` analysiert die vorbereiteten UTF-8-Dateien in `data/processed/` und schreibt strukturierte Ergebnisse nach `data/processed/linguistic_metrics.json`. Es werden keine externen Dienste oder Pakete verwendet. Die Eingabetexte werden nicht veraendert. Die JSON-Ausgabe enthaelt Schema-Version, Analysekonfiguration, Dateinamen und Kennzahlen pro Text.

Alle Berechnungen sind deterministisch: Dateien werden alphabetisch sortiert, Frequenzgleichstaende alphabetisch aufgeloest, JSON-Schluessel stabil sortiert und Verhaeltnisse auf sechs Nachkommastellen gerundet. Die Analyse versioniert die lokale Funktionswortliste als `voyagestylo-de-historical-v2`.

## Tokenisierung

Ein Worttoken ist eine zusammenhaengende Folge Unicode-Buchstaben (`L`) mit angehaengten kombinierenden Zeichen (`M`). Ein inneres gerades oder typographisches Apostroph bleibt Bestandteil, wenn darauf ein Buchstabe folgt, z. B. `John's`. Ziffern, Bindestriche und sonstige Satzzeichen trennen Tokens; Zahlen sind keine Worttokens. Historische Buchstaben wie langes s (`ſ`) und kombinierende Akzente bleiben erhalten. Es gibt keine OCR-Korrektur, kein Stemming, keine Lemmatisierung und keine Ausschlussliste fuer ungewoehnliche Formen.

Bei Wortfrequenz-, Typ- und TF-IDF-Aggregationen wird ausschliesslich `str.lower()` benutzt. Das vereinheitlicht Gross-/Kleinschreibung, modernisiert aber keine Schreibweise: insbesondere werden `ſ` dort nicht in `s` und `ß` nicht in `ss` umgewandelt. Sichtbare Wortformen werden zusaetzlich mit ihrer urspruenglichen Gross-/Kleinschreibung gezaehlt. Ausschliesslich die Funktionswortklassifikation gleicht `ſ` fuer den exakten Inventarabgleich mit `s` ab. Diese begrenzte Zuordnung erhaelt historische Wortformen in den uebrigen Ausgaben.

## Kennzahlen

### Anzahl der Woerter

Misst die Gesamtzahl erkannter Worttokens. Berechnung: Zahl der Token aus der Unicode-Tokenisierung. Historische Zusammensetzungen mit Bindestrich werden in zwei Tokens geteilt; eine abgetrennte Zeilenfortsetzung kann ebenfalls als zwei Tokens erscheinen. Zahlen werden nicht mitgezaehlt.

### Anzahl der Saetze

Misst die Zahl der erkannten Satzsegmente. Ein Segment endet bei `.`, `!`, `?` oder `…`; Leerzeilen gelten als Absatzgrenzen. Nichtleere, unpunktierte Absatzreste zaehlen als Satzfragment. Perioden nach einem festen Abkuerzungsverzeichnis (u. a. `Dr.`, `Prof.`, `z. B.`-Bestandteile, `u. s. w.`-Bestandteile) beenden keinen Satz.

Historische Abkuerzungen, OCR-Fehler und Fraktursatz koennen von der Liste abweichen. Die Satzanzahl ist daher eine transparente Heuristik, keine manuell validierte Satzannotation. Komplexe Abkuerzungen koennen weiter zu falschen oder fehlenden Grenzen fuehren.

### Durchschnittliche Satzlaenge

Misst die durchschnittliche Zahl der Worttokens pro Satzsegment. Berechnung: Gesamtwortzahl geteilt durch Satzanzahl; bei null Saetzen wird `0.0` ausgegeben. Absatzfragmente ohne Endzeichen gehen als Segmente ein. OCR-Fehler in Satzzeichen und Abkuerzungen wirken direkt auf diesen Wert.

### Durchschnittliche Wortlaenge

Misst durchschnittliche Unicode-Buchstaben pro Worttoken. Berechnung: Anzahl der Codepoints mit Unicode-Kategorie `L` in allen Tokens geteilt durch Wortzahl. Apostrophe und kombinierende Zeichen werden bei der Laenge nicht mitgezaehlt; langes s zaehlt als Buchstabe. Der Wert ist keine typographische Zeichenbreite und keine Silbenzahl.

### Type-Token-Ratio

Misst lexikalische Vielfalt als Zahl unterschiedlicher Types geteilt durch Worttokens. Types werden mit `str.lower()` gebildet, aber nicht casefolded, normalisiert oder lemmatisiert. `Daß` und `daß` sind derselbe Type; `daß` und `dass` sowie `ſeyn` und `seyn` bleiben getrennte Types. Die TTR haengt stark von Textlaenge und OCR-Qualitaet ab und ist zwischen Texten unterschiedlicher Laenge nur eingeschraenkt vergleichbar.

### Hapax Legomena: Anzahl und Anteil

Ein Hapax Legomenon ist hier ein case-normalisierter Type, der im jeweiligen ganzen Dokument genau einmal vorkommt. `hapax_legomena_count` ist die Zahl solcher Types. `hapax_type_share` teilt sie durch die Zahl aller Types; `hapax_token_share` teilt dieselbe Hapax-Zahl durch die Gesamtzahl der Tokens. Da jeder Hapax genau ein Token beitraegt, entspricht die Hapax-Zahl auch der Zahl entsprechender Tokens. OCR-Splitting und unterschiedliche Dokumentlaengen beeinflussen beide Anteile.

### Haeufigste Woerter

Misst die haeufigsten Types nach Gross-/Kleinschreibungsaggregation mit `str.lower()`. Ausgegeben werden bis zu 20 Eintraege (konfigurierbar), jeweils mit absoluter Zahl und Anteil an allen Worttokens. Gleichstaende werden alphabetisch sortiert. Es werden keine Woerter wegen Seltenheit, Alter oder vermuteter OCR-Fehler entfernt.

### Haeufigste Wortformen

Misst haeufige Oberflaechenformen exakt in der geschriebenen Form und Gross-/Kleinschreibung. Die Sortierung folgt Zahl absteigend, dann Unicode-Text aufsteigend. OCR-Varianten werden nicht automatisch zusammengefuehrt; dadurch koennen Fehlablesungen als eigene Formen erscheinen.

### Nomen- und Ortsnamen-Kandidaten

`most_frequent_noun_candidates` ist eine transparente Grossschreibungsheuristik, keine morphologische Wortarten- oder Eigennamenerkennung. Als Kandidaten gelten Tokens mit mindestens drei Buchstaben, die in der vorhandenen Satzsegmentierung nicht am Satzanfang stehen, mit einem Grossbuchstaben beginnen und nicht in der Funktionswortliste (einschliesslich der begrenzten Lang-s-Zuordnung) oder der kleinen Liste haeufiger Kontraktionen stehen. Nach Ermittlung dieser Kandidaten werden alle Vorkommen ihrer kleingeschriebenen Form im Text gezählt und nach Häufigkeit absteigend, dann alphabetisch ausgegeben; `top_n` begrenzt die Liste, standardmässig auf 20.

Diese Heuristik findet häufig Nomen und Orts-/Personennamen in deutscher Grossschreibung, unterscheidet sie aber nicht sicher voneinander und kann auch andere grossgeschriebene Wörter oder OCR-Fehler aufnehmen. Klein geschriebene OCR-Nomen werden nicht als Kandidaten erkannt, wenn sie sonst nirgends in Kandidatenposition stehen. Nomen, die ausschliesslich am Satzanfang vorkommen, können fehlen. Historische Formen und OCR-Varianten werden nicht vereinheitlicht. Die Anzeige in der Weboberfläche muss daher als „Nomen-/Ortsnamen-Kandidaten“ verstanden und nicht als geprüfte Ortsnamenliste verwendet werden.

### Funktionswortverteilung

Misst erkannte Tokens aus der versionierten, lokalen Liste `src/function_words.py`. Das Ergebnis umfasst Gesamtzahl und Anteil an allen Worttokens, Frequenzen der einzelnen Listeneintraege sowie Anzahl/Anteil je Gruppe: Artikel und Determinierer, Pronomen, Praepositionen, Konjunktionen, Hilfs-/Modalverben und Partikeln. Die Liste enthaelt explizite historische Varianten, darunter `bey`, `daß`, `seyn` und `sey`.

Die Zuordnung erfolgt durch exakte Mitgliedschaft des kleingeschriebenen Tokens, mit der genannten Lang-s-Entsprechung nur fuer diesen Listenabgleich, nicht kontextsensitiv. Formen wie `sein`, `als`, `doch` oder `nach` koennen je nach Verwendung verschiedene Funktionen haben. Die Liste ist ein reproduzierbares Analyseinstrument, keine vollstaendige grammatische Annotation. Nicht gelistete Funktionswoerter werden nicht erraten und nicht aus dem Wortzaehler entfernt.

Die Gruppen sind disjunkt, damit jeder gelistete Token hoechstens eine Gruppe erhoeht. Mehrdeutige Formen werden lexikalisch fest zugeordnet: `sein` steht in der Auxiliargruppe; `meiner`, `deiner`, `ihr`, `unser` und `euer` stehen in der Pronomen-Gruppe. Diese feste Zuordnung ersetzt keine kontextuelle POS-Analyse.

## Historische und technische Grenzen

- OCR kann Satzzeichen, Buchstaben, Trennungen und `ſ` falsch erkennen; alle darauf beruhenden Metriken erben diesen Fehler.
- Die Vorverarbeitung faltet Zeilen innerhalb von Absaetzen zusammen und entfernt nur dokumentierte Scan-Beigaben. Nicht erkannte Beifunde oder Seitenzahlen koennen weiterhin mitgezaehlt werden.
- Das gleiche sichtbare historische Wort kann durch OCR in mehrere Varianten zerfallen. Die Analyse korrigiert oder modernisiert diese Formen nicht.
- Die Funktionswortliste ist bewusst fest und nachvollziehbar, aber unvollstaendig. Ergaenzungen benoetigen eine Versionsaenderung und passende Tests.
- Kennzahlen beschreiben das verarbeitete Dokument, nicht automatisch den reinen Haupttext oder eine isolierte Autorschaft. Genre, Thema, Uebersetzung, Umfang und OCR-Qualitaet muessen bei Vergleichen beruecksichtigt werden.

## Ausfuehren

```powershell
python src/linguistic_analysis.py
python src/linguistic_analysis.py --top-n 30 --output data/processed/metrics-top30.json
python -m unittest discover -s tests -v
```