# Korpusanalyse: VoyageStylo

Stand: 2026-09-28. Diese Bestandsaufnahme basiert auf den lokalen Projektdateien, den fuenf vollstaendig eingelesenen Dateien unter `data/raw/` und `data/metadata/source_manifest.json`. Es wurden keine Quelldateien veraendert, bereinigt oder modernisiert.

## 1. Korpusbestand und Bibliographie

Die Metadaten unten geben die im lokalen Manifest dokumentierten Angaben wieder. Die Jahreszahl ist das dort verzeichnete Erscheinungsjahr; weitergehende Editionsangaben werden nicht ergaenzt, wenn sie im lokalen Manifest fehlen.

| Rohdatei | Titel (Kurzform laut Manifest) | Urheber laut Manifest | Jahr | Archivnachweis |
| --- | --- | --- | ---: | --- |
| [`anders_sparrman_reise_vorgebirge_1784.txt`](../data/raw/anders_sparrman_reise_vorgebirge_1784.txt) | *Reise nach dem Vorgebirge der guten Hoffnung, den suedlichen Polarlaendern und um die Welt* | Anders Sparrman | 1784 | [Internet Archive 11449720bsb](https://archive.org/details/11449720bsb); [BSB/MDZ](https://www.digitale-sammlungen.de/en/view/bsb11449720) |
| [`carsten_niebuhr_reisebeschreibung_arabien_1774_1778.txt`](../data/raw/carsten_niebuhr_reisebeschreibung_arabien_1774_1778.txt) | *Reisebeschreibung nach Arabien und andern umliegenden Laendern* | Carsten Niebuhr | 1774 | [Internet Archive bub_gb_cFJKAAAAYAAJ](https://archive.org/details/bub_gb_cFJKAAAAYAAJ) |
| [`christian_joseph_jagemann_briefe_italien_1778.txt`](../data/raw/christian_joseph_jagemann_briefe_italien_1778.txt) | *Briefe ueber Italien* | Christian Joseph Jagemann | 1778 | [Internet Archive briefeberitalie01jagegoog](https://archive.org/details/briefeberitalie01jagegoog) |
| [`christoph_meiners_briefe_schweiz_1791.txt`](../data/raw/christoph_meiners_briefe_schweiz_1791.txt) | *Briefe ueber die Schweiz: mit Kupfern. 1* | Christoph Meiners | 1791 | [Internet Archive 10921483bsb](https://archive.org/details/10921483bsb); [BSB/MDZ](https://www.digitale-sammlungen.de/en/view/bsb10921483) |
| [`forster_reise_um_die_welt_1778.txt`](../data/raw/forster_reise_um_die_welt_1778.txt) | *Johann Reinhold Forster's Reise um die Welt waehrend den Jahren 1772 bis 1775* | Georg Forster; Johann Reinhold Forster | 1778 | [Internet Archive johannreinholdfo00fors](https://archive.org/details/johannreinholdfo00fors) |

**Beobachtung:** Das Korpus umfasst fuenf Dateien aus den Jahren 1774 bis 1791. Forster ist im Manifest mit zwei Urhebern verzeichnet. Zwei Titel sind ausdruecklich als Briefe bezeichnet; sie sind deshalb nicht ohne Weiteres strukturgleich mit den als Reisebeschreibung/Reise bezeichneten Werken.

**Unsicher bzw. nicht dokumentiert:** Beim Meiners-Titel ist `1` Bestandteil des Titels und weist auf Band 1 hin; die genaue Abgrenzung des hier transkribierten Textes ist nicht weiter beschrieben. Der Niebuhr-Dateiname enthaelt `1774_1778`, waehrend das Manifest nur 1774 als Erscheinungsjahr nennt. Ob der Dateiname eine mehrbaendige Publikationsspanne oder den Umfang dieser konkreten Datei meint, ist aus dem lokalen Manifest nicht ersichtlich. Beim Sparrman-Titel nennt das Manifest keinen Uebersetzer. Weitere Auflagen-, Druckort-, Verlags-, Seiten- und Exemplar-Angaben fehlen im lokalen Manifest weitgehend.

## 2. Umfang der Dateien

Die folgenden Werte wurden aus den unveraenderten Dateien gelesen. `Zeichen` ist die von .NET `String.Length` gelieferte Zahl an UTF-16-Codeeinheiten und schliesst Leerzeichen und Zeilenumbrueche ein. `Tokenkandidaten` zaehlt Treffer des Ausdrucks `\p{L}[\p{L}\p{M}]*`: ein Unicode-Buchstabe, gefolgt von Buchstaben oder kombinierenden Zeichen. Das ist eine reproduzierbare Grobschaetzung, keine linguistisch validierte Wortzahl.

| Datei | Bytes | Zeichen | Tokenkandidaten | Zeilen* |
| --- | ---: | ---: | ---: | ---: |
| Sparrman | 1.165.357 | 1.107.694 | 167.492 | 28.522 |
| Niebuhr | 1.197.391 | 1.161.477 | 180.243 | 26.052 |
| Jagemann | 300.272 | 291.625 | 47.890 | 9.012 |
| Meiners | 448.592 | 424.008 | 63.696 | 16.078 |
| Forster | 1.198.300 | 1.142.993 | 173.094 | 19.641 |

\* Zeilenanzahl aus der Aufteilung an CRLF, LF oder CR; eine abschliessende Leerzeile kann mitgezaehlt werden. Die Tokenzahlen schliessen OCR-Vorspann, Titelblaetter, Register, Bibliotheksvermerke und sonstige Beifunde mit ein, sofern sie im jeweiligen Textfile stehen. Sie sind daher nicht mit dem Umfang des eigentlichen Reiseberichts gleichzusetzen.

## 3. OCR-Befund

**Beobachtungen aus den Rohdateien:** Alle fuenf Dateien sind laut Manifest DjVuTXT-OCR-Ableitungen und keine Bildscans. Die Dateien enthalten keine Form-Feed-Seitenmarken. Seiten-/Druckstruktur ist aber teilweise ueber alleinstehende Seitenzahlzeilen und Zeilenumbrueche sichtbar. Die verwendeten OCR-Systeme unterscheiden sich: vier Eintraege nennen Tesseract, Jagemann ABBYY FineReader 8.0.

Als transparente, rein deskriptive Indikatoren wurden gezaehlt: Zeilen, deren Inhalt nach Trimmen nur aus einer Zahl mit optionalem Punkt/Klammer besteht; Zeilen ab 30 Zeichen, bei denen weniger als 45 Prozent der Zeichen Buchstaben sind; sowie moegliche Trennungen mit Bindestrich am Zeilenende. Diese Schwellen sind Heuristiken, keine OCR-Qualitaetsbewertung.

| Datei | Nur-Seitenzahl-Zeilen | Niedrige Buchstabendichte | Moegliche Zeilen-Trennungen |
| --- | ---: | ---: | ---: |
| Sparrman | 78 | 18 | 227 |
| Niebuhr | 96 | 159 | 234 |
| Jagemann | 40 | 4 | 27 |
| Meiners | 324 | 4 | 81 |
| Forster | 47 | 190 | 69 |

Die Indikatoren erfassen unterschiedliche Probleme und sind nicht direkt als Rangliste der Textqualitaet zu lesen. Jagemann hat beispielsweise nur wenige Zeilen mit niedriger Buchstabendichte, aber deutliche Buchstabenverwechslungen.

- **Sparrman:** Der Dateianfang enthaelt viele kurze, fragmentierte und mit Zahlen/Zeichen vermischte Zeilen; Titel- und Abbildungs-/Bildtext-OCR ist dort stark gestoert. Im Text stehen wiederholt `Vorrede`-Zeilen. Korrekturhinweise wie `... statt ..., lies ...` sind erkennbar. Am Ende folgen Bibliotheks-/Exemplarangaben. Einzelne Formen wie `fie` koennen OCR-Verwechslungen sein, sind aber ohne Abgleich am Scan nicht sicher zu korrigieren.
- **Niebuhr:** Der Anfang und das Ende enthalten auffaellig viele Striche, Einzelzeichen und Fragmente; 159 laengere Zeilen unterschreiten die Buchstabenschwelle. Im Fliesstext finden sich sichtbare Fehlformen bzw. Verdachtsfaelle wie `fchon`, `fie`, `nad)` und getrennte Wortreste. Manche koennen aus der Erkennung des langen s oder aus Zeilen-/Fraktur-OCR stammen; die urspruengliche Lesart ist ohne Scanabgleich unsicher.
- **Jagemann:** Die Datei beginnt mit einem englischen Google-Digitalisierungsvermerk, der selbst stark fehlgelesen ist, etwa `This is a digital copy of a bix>k ...`. Am Ende steht ein Stanford-Bibliotheks-/Ausleihvermerk. Auch im deutschsprachigen Teil finden sich stark zerstoerte Zeichenfolgen, zum Beispiel `Sjiefe Briefe ftnb W&er ferffrenet`. Das kann den Wortschatz und die Tokenisierung massiv verfremden.
- **Meiners:** Das Titel-/Vorspannmaterial ist teilweise fehlerhaft, etwa die OCR-Form `[hrisfoph]`. Es gibt 324 alleinstehende Seitenzahlzeilen und viele einzelne kurze Zeilen. Am Ende stehen BSB/MDZ-Katalogangaben.
- **Forster:** Vor- und Schlussmaterial enthalten zahlreiche kurze, zahlen- und symbolhaltige Zeilen; 190 laengere Zeilen unterschreiten die Buchstabenschwelle. Inhalts-/Abschnittsangaben sind erkennbar, aber auch dort gibt es Fehlformen. Die Angaben zu Gesellschaften und Orten enthalten Abkuerzungen, die nicht automatisch als OCR-Fehler gelten duerfen.

## 4. Historische Schreibweisen

**Beobachtung:** Die Roh-OCR bewahrt in mehreren Dateien das lange s `ſ` und historische Schreibungen, zum Beispiel bei Forster `Forſter's`, `Geſellſch.`, `Reiſe` und `ſchoͤnen`; bei Meiners `Reiſe`, `dieſes`, `beſchriebene` und `jemahls`; bei Sparrman `ſaͤtze` und `ſcientifiſchen`. Sichtbar sind auch Schreibungen wie `daß`, `bey`, `thun` und `giengen`. Diese Formen sind Datenmerkmale und duerfen nicht stillschweigend modernisiert werden.

**Unsicherheit:** Ein OCR-Text bildet den Druck nicht verlaesslich ab. Die Erkennung kann `ſ` als `f` ausgeben; kombinierende Zeichen und historische Ligaturen koennen getrennt, ersetzt oder verloren sein. Im Jagemann-Eintrag (ABBYY) kommt im extrahierten Text kein `ſ` vor; daraus folgt nicht, dass der historische Druck kein langes s enthielt. Unterschiedliche OCR-Systeme koennen Schreibweisen unterschiedlich normalisieren. Vor jeder orthographischen Interpretation waere ein Vergleich mit den Digitalisaten erforderlich.

## 5. Textstruktur

- **Forster:** Im OCR sind Inhalts-/Abschnittsangaben sichtbar; der Text verweist auf Teile bzw. Buecher, darunter einen neuen Abschnitt/das dritte Buch. Eine Schlussuebersicht nennt unter anderem die Azorischen Inseln, Fayal und die Rueckkehr nach England. Das spricht fuer eine gegliederte Expeditionsdarstellung mit separatem Inhaltsmaterial.
- **Sparrman:** Eine Vorrede ist mehrfach markiert; neben Erzaehlung erscheinen wissenschaftlich bzw. naturkundlich wirkende Inhalte, Bild-/Objektbeschriftungen und Korrekturhinweise. Die exakte Gliederung ist wegen der OCR-Qualitaet nicht vollstaendig rekonstruierbar.
- **Niebuhr:** Der Text enthaelt Vorrede-Verweise sowie fortlaufende Reise-/Sachbeschreibung. OCR-Linien und Seitenzahlen sind eingestreut; eine stabile Kapitelgliederung laesst sich aus dieser automatischen Bestandsaufnahme nicht sicher angeben.
- **Jagemann:** Der Titel bezeichnet Briefe; im OCR findet sich ausdruecklich `dritter Brief`. Die Datei enthaelt zusaetzlich Google-Vorspann und Stanford-Bibliotheksmaterial, die nicht zum historischen Brieftext gehoeren.
- **Meiners:** Der Titel bezeichnet Briefe und Band 1; im Text ist eine Vorrede erkennbar. Seitenzahlzeilen und Katalogmaterial stehen neben dem eigentlichen Text.

**Methodische Einordnung:** Die fuenf Dateien sind keine homogene Textsorte. Zwei Titel sind Briefsammlungen; die anderen sind als Reise bzw. Reisebeschreibung bezeichnet. Forster ist im Manifest mit zwei Urhebern verzeichnet. Thematische, gattungsspezifische, uebersetzungs- und editionsbedingte Unterschiede koennen stilometrische Merkmale beeinflussen und sind nicht gleichbedeutend mit Autorunterschieden.

## 6. Risiken fuer automatische Analyse

1. **OCR-verfaelschter Wortschatz:** Verwechslungen wie `ſ`/`f`, zerlegte Zeilen, falsche Buchstaben und eingestreute Zeichen veraendern Wortformen, Wortfrequenzen, TTR und Funktionswortzaehlungen. Ein statistisch wiederkehrender OCR-Fehler kann faelschlich als Stilmerkmal erscheinen.
2. **Nichttext im Rohfile:** Vorreden, Inhaltsverzeichnisse, Seitenzahlen, Register, Bildunterschriften, Errata, Bibliotheksstempel/-zettel und Google-/MDZ-Beifunde mischen sich mit dem Bericht. Sie sollten nicht stillschweigend aus den Rohdateien geloescht werden; eine abgegrenzte Analysefassung benoetigt dokumentierte Regeln.
3. **Zeilenumbrueche und Trennstriche:** OCR-bedingte Zeilenumbrueche koennen Woerter zerlegen oder Bindestriche als Wortbestandteil behandeln. Einfache Wort- und Satzzaehlungen sind davon abhaengig.
4. **Historische Orthographie und Unicode:** `ſ`, `daß`, `bey`, `thun`, Umlaute/diakritische Zeichen und kombinierende Zeichen koennen in modernen Tokenizern, Stopwortlisten und Normalisierungen anders behandelt werden. Jede Normalisierung muss als separater, reproduzierbarer Schritt erfolgen.
5. **Satzgrenzen:** Die hier gezaehlten Tokenkandidaten sind keine Satzzaehlung. Punkt, Ausrufezeichen und Fragezeichen werden durch OCR, Abkuerzungen, Inhaltsverzeichnisse und Satzdruck beeinflusst; Satzanzahl und Satzlaenge brauchen eine explizite, evaluierte Segmentierungsregel.
6. **Ungleiche Laengen und Umfang:** Die Tokenkandidaten reichen von rund 47.900 bis 180.200 und enthalten Beifunde. TTR ist stark von Textlaenge abhaengig; direkte Rangfolgen oder PCA ueber unbereinigte Gesamtdateien waeren daher schwer interpretierbar.
7. **Vergleichbarkeit/PCA:** Fuenf Gesamttexte ergeben nur fuenf Beobachtungspunkte. Die Darstellung waere explorativ und empfindlich gegen OCR-Qualitaet, Textlaenge, Briefform, Sachthema, Uebersetzung und Merkmals-Skalierung. Segmentierung in vergleichbare Textabschnitte und Sensitivitaetspruefungen waeren vor belastbaren Aussagen noetig.

## 7. Fehlende Informationen und offene Entscheidungen

- Zuordnung von OCR-Seiten zu Druckseiten sowie sichere Abgrenzung von Haupttext, Vorrede, Inhaltsverzeichnis, Registern und Nachtraegen.
- Bibliographische Vollangaben pro konkreter Datei: genaue Ausgabe/Auflage, Druckort und Verlag, Bandumfang/Seitenbereich und gegebenenfalls Uebersetzer. Die lokale Metadatendatei enthaelt dies nur teilweise.
- Dokumentierte Korpusauswahl: Warum gerade diese fuenf Texte, welche Ausschlusskriterien gelten und wie repraesentativ die Auswahl sein soll.
- OCR-Qualitaet pro Seite bzw. manuell validierte Stichproben. Die globale OCR-Engine-Angabe ist keine Genauigkeitsmessung.
- Rechte-/Lizenzangaben fuer alle Dateien. Laut lokalem Manifest traegt nur der Niebuhr-Datensatz ausdruecklich eine Public Domain Mark; fuer die uebrigen fehlen dort explizite Rechteangaben.
- Festlegung, welche Textteile stilometrisch analysiert werden sollen und wie OCR-Fehler, Trennungen, Orthographie, Gross-/Kleinschreibung und Funktionswortlisten behandelt werden.
- Reproduzierbare Definitionen fuer Wort/Satz, Wortlaenge, haeufigste Woerter, Stopwoerter, Funktionswortverteilung und vergleichbare Segmentgroessen.

**Dokumentationsabweichung:** `README.md` sagt, es seien noch keine historischen Korpusdaten enthalten und `data/raw/` sei fuer Originaldateien reserviert. Im aktuellen Bestand liegen jedoch fuenf OCR-Textableitungen; die zugrunde liegenden Seitenbilder sind nicht in `data/raw/` abgelegt. Die README-Aussage ist damit fuer den aktuellen Projektstand veraltet.

## 8. Reproduzierbarkeit und Aenderungsumfang

Die Dateiwerte und OCR-Indikatoren wurden lokal und lesend aus allen fuenf Dateien berechnet. Die Tokenregel und Schwellenwerte sind oben angegeben; OCR-Indikatoren sind Diagnoseheuristiken und keine korrigierten Daten. Bibliographische Angaben stammen aus `data/metadata/source_manifest.json`. Dort stehen auch Archiv-IDs, Download-URLs, OCR-Systeme und MD5-Werte.

Es wurden ausschliesslich die Rohdateien gelesen. Diese Analyse hat weder Korpusdateien noch Metadaten veraendert oder bereinigt. Unsichere OCR-Lesarten sind als solche markiert; es wurde keine fehlende historische Information ergaenzt.
