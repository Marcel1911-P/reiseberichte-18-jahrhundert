# Stilometrischer Textvergleich

## Zweck und Interpretation

`src/stylometry.py` vergleicht die vorbereiteten UTF-8-Texte lokal und reproduzierbar. Es berechnet eine TF-IDF-Repräsentation und eine davon getrennte Repräsentation der Funktionswörter. Für beide werden Cosinus-Ähnlichkeits- und Distanzmatrizen ausgegeben. Höhere Ähnlichkeit bzw. kleinere Distanz bedeuten lediglich, dass die jeweiligen Merkmalsvektoren ähnlicher sind.

Die Analyse beschreibt ausschliesslich sprachliche Ähnlichkeiten und Unterschiede in den untersuchten Texten. Sie stellt keine Behauptungen über wahre Autorschaft, Identität, Absicht oder andere Eigenschaften auf, die nicht durch die Daten belegt sind.

Ausführen:

```powershell
python src/stylometry.py
python src/stylometry.py --input-dir data/processed --output data/processed/stylometry.json
python -m unittest discover -s tests -v
```

Standardmässig liest das Programm `.txt`-Dateien aus `data/processed/` und schreibt `data/processed/stylometry.json`. Dateien und Matrixachsen werden alphabetisch sortiert. Es werden ausschliesslich die lokale Python-Standardbibliothek, `tokenize_words` aus `src/linguistic_analysis.py` und die versionierte lokale Funktionswortliste verwendet; Texte und Analyseergebnisse werden nicht an externe Dienste gesendet.

## Verwendete Merkmale

### TF-IDF über alle Worttokens

Die Tokenisierung entspricht der vorhandenen linguistischen Analyse: Unicode-Buchstaben mit kombinierenden Zeichen, Apostrophe innerhalb von Wörtern; Ziffern und Satzzeichen trennen Tokens. Das kleingeschriebene Token wird als Merkmal verwendet. Historische Schreibweisen bleiben erhalten; `ſ` wird nicht zu `s`, `daß` nicht zu `dass` und `seyn` nicht zu `sein` normalisiert. Es gibt kein Stemming, keine Lemmatisierung und keine OCR-Korrektur.

Die Termfrequenz (TF) ist die rohe Anzahl eines Tokens im Dokument. Die geglättete inverse Dokumentfrequenz (IDF) lautet `log((1 + N) / (1 + df)) + 1`, wobei `N` die Zahl der Dokumente und `df` die Zahl der Dokumente mit dem Token bezeichnet. Das Produkt TF×IDF wird je Dokument auf L2-Einheitslänge normiert. Ausgegeben werden die sparsamen Gewichte pro Dokument, die verwendete Vokabularliste sowie eine Cosinus-Ähnlichkeits- und eine `1 - Ähnlichkeit`-Distanzmatrix.

Die TF-IDF-Merkmale enthalten ausdrücklich auch Funktionswörter. Häufige Wörter, die in vielen Dokumenten vorkommen, erhalten durch die IDF-Gewichtung weniger Gewicht, werden aber nicht pauschal entfernt. Damit bleiben sowohl seltenere Inhaltswörter als auch gemeinsame Funktionswörter in der lexikalischen Vergleichsansicht sichtbar.

### Funktionswortverteilung

Als separates stilistisches Merkmal dient jedes Wort der lokalen, disjunkten Liste `voyagestylo-de-historical-v2` aus `src/function_words.py` (Artikel/Determinierer, Pronomen, Präpositionen, Konjunktionen, Hilfs-/Modalverben und Partikeln). Jedes Merkmal ist seine Tokenzahl geteilt durch die Gesamtzahl der Worttokens des Dokuments. Die Funktionswortmatrix vergleicht diese relativen Häufigkeitsvektoren mit dem Cosinusmass. Die versionierte Liste `voyagestylo-de-historical-v2` gleicht langes s (`ſ`) nur bei der Funktionswort-Zuordnung mit `s` ab (z. B. `ſich` → `sich`, `iſt` → `ist`). Das sichtbare Token, die Wortformstatistik und TF-IDF bleiben unverändert; es gibt keine allgemeine Rechtschreibmodernisierung.

Die Liste enthält ausgewählte historische Varianten. Die Zuordnung erfolgt lexikalisch und nicht kontextsensitiv; mehrdeutige Formen können im konkreten Satz eine andere grammatische Funktion haben. Die Liste ist weder vollständig noch eine POS-Annotation. Ihre Version wird in den Ergebnissen festgehalten.

### Ergänzende Kennzahlen

Zusätzlich liefert `descriptive_features` für jedes Dokument bisherige Kennzahlen: Wortzahl, Type-Token-Ratio, durchschnittliche Satz- und Wortlänge, Hapax-Anteile und die vorhandene Funktionswortverteilung. Diese helfen, einen Paarvergleich im Kontext zu beurteilen, werden aber nicht unbemerkt in die Cosinus-Matrizen eingerechnet.

## Kombination und Vergleich der Merkmale

Wortfrequenzen und Funktionswörter können sinnvoll nebeneinander interpretiert werden: TF-IDF vergleicht ein breites lexikalisches Profil, während die separate Funktionswortansicht stärker auf grammatische/strukturelle Wortwahl zielt. Die beiden Matrizen erlauben zu prüfen, ob ein Eindruck lexikalischer Nähe auch in der Funktionswortverteilung sichtbar ist.

Eine naive Verkettung von TF-IDF-Werten, Funktionsworthäufigkeiten, Wortlänge, TTR, Satzlänge und Hapax-Anteilen wäre nicht sinnvoll: Die Blöcke haben verschiedene Dimensionen und Skalen, und einzelne Werte wie TTR hängen deutlich von Textlänge ab. Sie könnten einander im Cosinusvergleich unverhältnismässig dominieren. Deshalb wird kein zusammengefasster Gesamtscore ausgegeben (`combined_score` ist `null`). Eine künftige kombinierte Auswertung müsste zunächst Merkmalsauswahl, blockweise Skalierung/Gewichtung und Textlängenkontrolle begründen und gegen die separaten Ergebnisse prüfen.

## Vorverarbeitung

1. Die Analyse liest die bereits vorbereiteten `data/processed/*.txt`-Dateien streng als UTF-8; die Rohtexte in `data/raw/` werden nicht geändert.
2. Die dokumentierte Pipeline in `docs/preprocessing.md` vereinheitlicht Zeilenenden, entfernt nur eng erkannte Scan-Beigaben/Seitenzahlfolgen und fügt OCR-Zeilen innerhalb eines Absatzes zusammen. Unklare ASCII-Trennstriche bleiben bestehen.
3. Bei der Tokenisierung werden Gross-/Kleinschreibung für den Vergleich mit `str.lower()` vereinheitlicht. Nur die Funktionswortklassifikation gleicht zusätzlich langes s für den Listenabgleich mit `s` ab; die Worttokens bleiben in TF-IDF und Wortformstatistiken erhalten. Es findet keine allgemeine Unicode-Normalisierung, Modernisierung historischer Orthographie, OCR-Korrektur, Lemmatisierung oder manuelle Bereinigung statt.
4. Satzlängen und andere vorhandene Kennzahlen verwenden die dokumentierten Heuristiken aus `src/linguistic_analysis.py`. TF-IDF ignoriert die Satzgrenzen und zählt Worttokens über das gesamte Dokument.

Diese Schritte beeinflussen die Merkmale und sollten bei Reproduktion oder Korpusänderung gemeinsam mit der Funktionswortlisten-Version dokumentiert werden.

## Einschränkungen

- Cosinuswerte messen Ähnlichkeit der gewählten Repräsentation, keine Ursache oder Bedeutung. TF-IDF kann thematische Überschneidung abbilden und ist allein kein reines Stilmass.
- Selbst bei separatem Funktionswortvergleich können Textsorte, Gattung, Thema, Übersetzung, Edition und Überlieferung grammatische Wortwahl beeinflussen.
- Die lokale Wortliste ist begrenzt und mehrdeutige Formen werden nicht im Kontext disambiguiert. Nicht erkannte oder anders geschriebene Funktionswörter fehlen in diesem Merkmalsblock.
- Die Methode ist dokumentbasiert. Sehr kurze Texte ergeben instabile Häufigkeitsprofile; bei Texten ohne Tokens beziehungsweise ohne Funktionswörter ist der Nullvektor definiert und seine Ähnlichkeit auch zu sich selbst als `0` ausgewiesen, weil Cosinus für Nullvektoren mathematisch nicht definiert ist.
- Die Matrizen sind relativ zu genau den verglichenen Dokumenten: Wird das Korpus erweitert, kann sich die IDF und somit TF-IDF-Gewichtung verändern.
- Die Ausgabe ist kein statistischer Signifikanztest und liefert keine Unsicherheitsintervalle oder Korrektur für abhängige Texte.

## Textlänge und OCR-Fehler

L2-Normierung macht TF-IDF-Vektoren weniger unmittelbar von der absoluten Dokumentlänge abhängig, beseitigt den Längeneffekt jedoch nicht. Kürzere Texte enthalten weniger Wortvorkommen und können daher stark von einzelnen Tokens geprägt sein. Die relativen Funktionsworthäufigkeiten sind ebenfalls bei wenigen Tokens besonders empfindlich; bei längeren Texten stabilisieren sich Häufigkeiten tendenziell, sofern Abschnitte und Textsorten vergleichbar sind. Eine Ähnlichkeit zwischen unterschiedlich langen Dokumenten muss daher vorsichtig interpretiert werden; die Wortzahl in `descriptive_features` macht einen Teil dieses Unterschieds sichtbar.

OCR-Fehler können Tokens verfälschen, teilen, zusammenziehen oder mit Satzzeichen verwechseln. Das erzeugt neue TF-IDF-Merkmale oder verändert Häufigkeiten, während fehlerhafte Funktionswörter aus dem Inventar herausfallen können. OCR-Qualität kann so Ähnlichkeiten künstlich senken oder Unterschiede erzeugen. Da keine unsichere automatische Korrektur erfolgt, bleiben Rohorthographie und Fehler transparent; die Kennzahlen beschreiben die vorliegende OCR-Transkription, nicht zwingend den Drucktext.
