import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from src.web_app import analyze_selection, corpus_overview, create_server


class WebAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.processed = self.root / "processed"
        self.processed.mkdir()
        self.manifest_path = self.root / "manifest.json"
        self.names = ["a.txt", "b.txt"]
        (self.processed / "a.txt").write_text("Bey der Reise. Und bey Nacht.", encoding="utf-8")
        (self.processed / "b.txt").write_text("In der Ferne reisen.", encoding="utf-8")
        self.manifest_path.write_text(
            json.dumps(
                {
                    "documents": [
                        {
                            "file": "a.txt",
                            "title": "Reise nach Arabien während den Jahren 1760 bis 1765",
                            "creator": "Test Author",
                            "publication_year": 1770,
                        },
                        {
                            "file": "b.txt",
                            "title": "Reise um die Welt",
                            "creator": "Second Author",
                            "publication_year": 1775,
                        },
                    ]
                }
            ),
            encoding="utf-8",
        )

    def tearDown(self):
        self.temporary.cleanup()

    def test_overview_includes_source_metadata_and_processed_word_counts(self):
        overview = corpus_overview(self.processed, self.manifest_path)
        documents = overview["documents"]

        self.assertEqual(documents[0]["author"], "Test Author")
        self.assertEqual(documents[0]["publication_year"], 1770)
        self.assertEqual(documents[0]["travel_period"], "1760–1765 (laut Titel)")
        self.assertEqual(documents[0]["destination"], "Arabien und umliegende Länder (laut Titel)")
        self.assertEqual(documents[0]["word_count"], 6)
        self.assertIsNone(documents[1]["travel_period"])

    def test_selection_uses_existing_analyses_and_can_choose_tfidf_pca(self):
        result = analyze_selection(
            ["b.txt", "a.txt"],
            "tfidf",
            self.processed,
            self.manifest_path,
        )

        self.assertEqual(result["stylometry"]["documents"], ["a.txt", "b.txt"])
        self.assertEqual(result["pca"]["feature_set"], "tfidf")
        self.assertEqual(len(result["documents"]), 2)
        self.assertEqual(result["documents"][0]["metrics"]["word_count"], 6)
        self.assertIn("function_word_distribution", result["documents"][0]["stylometric_features"])

    def test_untrusted_or_invalid_selections_are_rejected(self):
        with self.assertRaises(ValueError):
            analyze_selection([], processed_dir=self.processed, metadata_path=self.manifest_path)
        with self.assertRaises(ValueError):
            analyze_selection(["../secret.txt"], processed_dir=self.processed, metadata_path=self.manifest_path)
        with self.assertRaises(ValueError):
            analyze_selection(["a.txt", "a.txt"], processed_dir=self.processed, metadata_path=self.manifest_path)
        with self.assertRaises(ValueError):
            analyze_selection(["a.txt"], "other", self.processed, self.manifest_path)

    def test_oversized_selection_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "no more than"):
            analyze_selection(
                [f"{index}.txt" for index in range(21)],
                processed_dir=self.processed,
                metadata_path=self.manifest_path,
            )


class WebHttpTests(unittest.TestCase):
    def test_local_http_serves_ui_corpus_and_selected_analysis(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            processed = root / "processed"
            processed.mkdir()
            (processed / "one.txt").write_text("Bey der Reise.", encoding="utf-8")
            metadata = root / "manifest.json"
            metadata.write_text(
                json.dumps(
                    {
                        "documents": [
                            {
                                "file": "one.txt",
                                "title": "Reise nach Italien",
                                "creator": "Author",
                                "publication_year": 1777,
                            }
                        ]
                    }
                ),
                encoding="utf-8",
            )
            server = create_server(
                "127.0.0.1",
                0,
                processed,
                metadata,
                Path(__file__).resolve().parents[1] / "web",
            )
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f"http://127.0.0.1:{server.server_address[1]}"
            try:
                with urlopen(base_url + "/") as response:
                    page = response.read().decode("utf-8")
                    self.assertEqual(response.status, 200)
                    self.assertIn("VoyageStylo", page)

                with self.assertRaises(HTTPError) as error:
                    urlopen(base_url + "/lenin.html")
                self.assertEqual(error.exception.code, 404)

                with urlopen(base_url + "/app.js") as response:
                    self.assertEqual(response.status, 200)
                    self.assertIn(b"updateStaleNotice", response.read())

                with urlopen(base_url + "/styles.css") as response:
                    self.assertEqual(response.status, 200)
                    self.assertNotIn(b"@import", response.read())

                with urlopen(base_url + "/api/corpus") as response:
                    corpus = json.loads(response.read())
                    self.assertEqual(corpus["documents"][0]["word_count"], 3)

                request = Request(
                    base_url + "/api/analyze",
                    data=json.dumps({"documents": ["one.txt"]}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(request) as response:
                    analysis = json.loads(response.read())
                    self.assertEqual(analysis["pca"]["documents"], ["one.txt"])
                    self.assertEqual(analysis["documents"][0]["metrics"]["word_count"], 3)

                bad_request = Request(
                    base_url + "/api/analyze",
                    data=json.dumps({"documents": ["../secret.txt"]}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as error:
                    urlopen(bad_request)
                self.assertEqual(error.exception.code, 400)

                invalid_json = Request(
                    base_url + "/api/analyze",
                    data=b"{invalid-json",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as error:
                    urlopen(invalid_json)
                self.assertEqual(error.exception.code, 400)

                oversized = Request(
                    base_url + "/api/analyze",
                    data=b" " * 16_385,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as error:
                    urlopen(oversized)
                self.assertEqual(error.exception.code, 413)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
