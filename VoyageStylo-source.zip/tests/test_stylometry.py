import json
import math
import tempfile
import unittest
from pathlib import Path

from src.function_words import FUNCTION_WORD_TO_GROUP
from src.stylometry import analyze_corpus, analyze_stylometry, save_corpus_analysis


class StylometryTests(unittest.TestCase):
    def test_tfidf_is_sparse_l2_normalized_and_retains_function_words(self):
        result = analyze_stylometry(
            {
                "first.txt": "Daß bey Nacht reist.",
                "second.txt": "Daß bey Tag reist.",
            }
        )
        vectors = result["tfidf"]["vectors"]

        self.assertEqual(result["documents"], ["first.txt", "second.txt"])
        self.assertIn("daß", vectors["first.txt"])
        self.assertAlmostEqual(
            math.sqrt(sum(weight**2 for weight in vectors["first.txt"].values())),
            1.0,
        )
        self.assertGreater(vectors["first.txt"]["daß"], 0)

    def test_function_word_vectors_use_relative_frequencies(self):
        result = analyze_stylometry(
            {
                "a.txt": "Daß bey Nacht reist.",
                "b.txt": "Nacht reist.",
            }
        )
        vector = result["function_words"]["vectors"]["a.txt"]

        self.assertEqual(vector["daß"], 0.25)
        self.assertEqual(vector["bey"], 0.25)
        self.assertEqual(vector["und"], 0.0)
        self.assertEqual(
            result["configuration"]["function_words"]["list_version"],
            "voyagestylo-de-historical-v2",
        )
        self.assertEqual(
            len(result["function_words"]["feature_names"]),
            len(FUNCTION_WORD_TO_GROUP),
        )

    def test_long_s_function_word_variants_are_counted_in_canonical_features(self):
        result = analyze_stylometry(
            {
                "historical.txt": "ſich iſt dieſe",
                "plain.txt": "sich ist diese",
            }
        )
        vectors = result["function_words"]["vectors"]

        self.assertEqual(vectors["historical.txt"], vectors["plain.txt"])
        self.assertGreater(
            result["function_words"]["similarity_matrix"][0][1],
            0.999,
        )
        self.assertIn("ſich", result["tfidf"]["vectors"]["historical.txt"])

    def test_function_word_similarity_is_cosine_of_relative_frequency_vectors(self):
        result = analyze_stylometry(
            {
                "a.txt": "bey bey der",
                "b.txt": "bey der der der",
            }
        )

        similarity = result["function_words"]["similarity_matrix"][0][1]
        self.assertGreater(similarity, 0.7)
        self.assertLess(similarity, 1.0)

    def test_similarity_and_distance_matrices_are_symmetric_and_aligned(self):
        result = analyze_stylometry(
            {
                "00-same.txt": "bey der Reise.",
                "01-copy.txt": "bey der Reise.",
                "other.txt": "und Nacht.",
            }
        )
        for block in ("tfidf", "function_words"):
            similarity = result[block]["similarity_matrix"]
            distance = result[block]["distance_matrix"]
            self.assertEqual(similarity[0][0], 1.0)
            self.assertEqual(similarity[0][1], 1.0)
            self.assertEqual(similarity[0][2], similarity[2][0])
            self.assertEqual(distance[0][2], round(1 - similarity[0][2], 6))
            self.assertEqual(distance[0][0], 0.0)

    def test_empty_and_no_function_word_documents_have_defined_scores(self):
        result = analyze_stylometry(
            {"00-empty.txt": "", "01-content.txt": "Reisebericht"},
        )

        self.assertEqual(result["tfidf"]["vectors"]["00-empty.txt"], {})
        self.assertEqual(
            result["tfidf"]["similarity_matrix"][0],
            [0.0, 0.0],
        )
        self.assertEqual(
            result["function_words"]["similarity_matrix"],
            [[0.0, 0.0], [0.0, 0.0]],
        )

    def test_invalid_input_is_reported(self):
        with self.assertRaises(ValueError):
            analyze_stylometry({})
        with self.assertRaises(ValueError):
            analyze_stylometry({"": "Text"})
        with self.assertRaises(TypeError):
            analyze_stylometry({"text.txt": None})


class StylometryCorpusTests(unittest.TestCase):
    def test_corpus_analysis_and_json_output_are_reproducible(self):
        with tempfile.TemporaryDirectory() as temporary:
            input_dir = Path(temporary) / "texts"
            input_dir.mkdir()
            (input_dir / "b.txt").write_text("bey der Reise.", encoding="utf-8")
            (input_dir / "a.txt").write_text("und Nacht.", encoding="utf-8")
            output = Path(temporary) / "stylometry.json"

            corpus = analyze_corpus(input_dir)
            save_corpus_analysis(input_dir, output)
            first = output.read_bytes()
            save_corpus_analysis(input_dir, output)
            second = output.read_bytes()

        self.assertEqual(corpus["documents"], ["a.txt", "b.txt"])
        self.assertEqual(first, second)
        data = json.loads(first)
        self.assertEqual(data["schema_version"], "1.0")
        self.assertIn("similarity_matrix", data["tfidf"])
        self.assertIn("distance_matrix", data["function_words"])
        self.assertIsNone(data["configuration"]["combined_score"])

    def test_empty_corpus_is_reported(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(FileNotFoundError):
                analyze_corpus(Path(temporary))


if __name__ == "__main__":
    unittest.main()
