import hashlib
import tempfile
import unittest
from pathlib import Path

from src.preprocess import (
    JAGEMANN_FILE,
    MEINERS_FILE,
    RAW_DIR,
    SPARRMAN_FILE,
    preprocess_text,
    process_corpus,
)


class PreprocessTextTests(unittest.TestCase):
    def test_reflows_lines_and_preserves_paragraphs_and_historical_spelling(self):
        raw = "Erſte Reiſezeile\nzweite Zeile⸗\nfortſetzung\n\nDaß es bey Nacht geschah.\n"

        processed = preprocess_text(raw)

        self.assertEqual(
            processed,
            "Erſte Reiſezeile zweite Zeilefortſetzung\n\nDaß es bey Nacht geschah.\n",
        )

    def test_removes_recognized_google_scan_notice_only_for_jagemann(self):
        raw = (
            "Google\nThis is a digital copy of a book\n"
            "Den gesamten Buchtext koennen Sie im Internet durchsuchen\n"
            "\nTitelblatt-OCR\nDritter Brief\n"
        )

        processed = preprocess_text(raw, JAGEMANN_FILE)

        self.assertNotIn("Google", processed)
        self.assertIn("Titelblatt-OCR", processed)
        self.assertIn("Dritter Brief", processed)

    def test_removes_recognized_bsb_catalog_tails(self):
        sparrman = (
            ("Historischer Text bleibt.\n" * 500)
            + "\nBamberg, Staatsbibliothek -- Geogr.i.o.417\n"
            "um:nbn.de:bvb:12-bsb11449720-2\n018 14633965-001\n"
        )
        meiners = (
            ("Historischer Text bleibt.\n" * 500)
            + "\nbisher. MDZ\n"
            "taatsBibliothel Digitale Bibliothek\n\n"
            "Meiners, Christoph, 1747-1810\nWien 1791\n"
            "um:nbn.de:bvb:12-bsb10921483-6\n018 80023479-001\n"
        )

        processed_sparrman = preprocess_text(sparrman, SPARRMAN_FILE)
        processed_meiners = preprocess_text(meiners, MEINERS_FILE)

        self.assertIn("Historischer Text bleibt", processed_sparrman)
        self.assertNotIn("Bamberg, Staatsbibliothek", processed_sparrman)
        self.assertNotIn("Digitale Bibliothek", processed_meiners)
        self.assertNotIn("Meiners, Christoph", processed_meiners)
        self.assertIn("bisher.", processed_meiners)

    def test_removes_only_interleaved_long_page_number_sequence(self):
        raw = "\n\n".join(
            part
            for number in range(2, 7)
            for part in (f"Textabschnitt {number} enthaelt historische Formen.", str(number))
        )

        processed = preprocess_text(raw)

        for number in range(2, 7):
            self.assertIn(f"Textabschnitt {number}", processed)
            self.assertNotRegex(processed, rf"(?m)^{number}$")

    def test_preserves_short_or_punctuated_numbered_content(self):
        raw = "Liste\n\n1.\nErster Punkt\n\n2.\nZweiter Punkt\n\n3\nEinzelne Zahl im Text\n"

        processed = preprocess_text(raw)

        self.assertIn("1.", processed)
        self.assertIn("2.", processed)
        self.assertIn("3", processed)

    def test_preserves_number_runs_without_prose_context(self):
        raw = "\n\n".join(("—", *(str(number) for number in range(52, 63)), "33"))

        processed = preprocess_text(raw)

        self.assertIn("52", processed)
        self.assertIn("62", processed)

    def test_preserves_ambiguous_ascii_hyphen(self):
        processed = preprocess_text("Nad-\nlaessigkeit bleibt mehrdeutig.\n")

        self.assertIn("Nad- laessigkeit", processed)


class CorpusPipelineTests(unittest.TestCase):
    def setUp(self):
        self.raw_files = sorted(RAW_DIR.glob("*.txt"))
        self.assertTrue(self.raw_files, "Expected the downloaded raw corpus")

    def _source_hashes(self):
        return {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in self.raw_files
        }

    def test_every_raw_file_gets_a_processed_copy_and_sources_are_unchanged(self):
        raw_hashes_before = self._source_hashes()
        raw_names_before = {path.name for path in RAW_DIR.glob("*.txt")}

        with tempfile.TemporaryDirectory() as temporary:
            outputs = process_corpus(RAW_DIR, Path(temporary))
            self.assertEqual({path.name for path in outputs}, raw_names_before)
            self.assertTrue(all(path.is_file() and path.stat().st_size for path in outputs))

        self.assertEqual(raw_names_before, {path.name for path in RAW_DIR.glob("*.txt")})
        self.assertEqual(raw_hashes_before, self._source_hashes())

    def test_processing_is_reproducible(self):
        with tempfile.TemporaryDirectory() as temporary:
            output_dir = Path(temporary)
            first = process_corpus(RAW_DIR, output_dir)
            first_hashes = {
                path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                for path in first
            }
            second = process_corpus(RAW_DIR, output_dir)
            second_hashes = {
                path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                for path in second
            }

        self.assertEqual(first_hashes, second_hashes)

    def test_historical_forms_survive_processing_of_real_corpus(self):
        forster = next(path for path in self.raw_files if path.name.startswith("forster_"))
        raw = forster.read_bytes().decode("utf-8")
        processed = preprocess_text(raw, forster.name)

        for form in ("ſ", "daß", "bey"):
            with self.subTest(form=form):
                self.assertIn(form, processed)


if __name__ == "__main__":
    unittest.main()