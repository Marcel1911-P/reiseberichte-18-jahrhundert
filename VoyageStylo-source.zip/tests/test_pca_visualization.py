import tempfile
import unittest
from pathlib import Path

from src.pca_visualization import (
    analyze_pca,
    calculate_pca,
    prepare_pca_data,
    render_pca_svg,
)
from src.stylometry import analyze_stylometry


class PcaPreparationTests(unittest.TestCase):
    def setUp(self):
        self.stylometry = analyze_stylometry(
            {
                "short.txt": "bey und.",
                "long.txt": "bey und. " * 100,
                "other.txt": "der die das Reise.",
            }
        )

    def test_preparation_uses_ordered_stylometric_features(self):
        prepared = prepare_pca_data(self.stylometry)

        self.assertEqual(prepared["feature_set"], "function_words")
        self.assertEqual(prepared["documents"], self.stylometry["documents"])
        self.assertEqual(len(prepared["matrix"]), 3)
        self.assertEqual(
            len(prepared["matrix"][0]),
            len(prepared["feature_names"]),
        )
        long_index = prepared["documents"].index("long.txt")
        short_index = prepared["documents"].index("short.txt")
        for long_value, short_value in zip(
            prepared["matrix"][long_index],
            prepared["matrix"][short_index],
        ):
            self.assertAlmostEqual(long_value, short_value)

    def test_tfidf_preparation_is_available_and_zero_fills_missing_terms(self):
        prepared = prepare_pca_data(self.stylometry, "tfidf")
        self.assertEqual(prepared["feature_set"], "tfidf")
        self.assertEqual(len(prepared["matrix"]), 3)
        self.assertTrue(all(len(row) == len(prepared["feature_names"]) for row in prepared["matrix"]))
        long_index = prepared["documents"].index("long.txt")
        short_index = prepared["documents"].index("short.txt")
        for long_value, short_value in zip(
            prepared["matrix"][long_index],
            prepared["matrix"][short_index],
        ):
            self.assertAlmostEqual(long_value, short_value)

    def test_invalid_feature_block_is_reported(self):
        with self.assertRaises(ValueError):
            prepare_pca_data(self.stylometry, "word_counts")

    def test_invalid_feature_values_are_reported(self):
        data = {
            "documents": ["a.txt"],
            "function_words": {"vectors": {"a.txt": {"und": float("nan")}}},
        }
        with self.assertRaises(ValueError):
            prepare_pca_data(data)


class PcaCalculationTests(unittest.TestCase):
    def test_known_matrix_has_expected_explained_variance(self):
        result = calculate_pca(
            {
                "documents": ["a.txt", "b.txt", "c.txt"],
                "feature_names": ["x", "y"],
                "matrix": [[1.0, 0.0], [0.0, 1.0], [-1.0, -1.0]],
                "feature_set": "test",
            }
        )

        self.assertAlmostEqual(result["explained_variance_ratio"][0], 0.75)
        self.assertAlmostEqual(result["explained_variance_ratio"][1], 0.25)
        self.assertAlmostEqual(
            sum(result["scores"][name][0] for name in result["documents"]),
            0.0,
        )

    def test_scores_and_explained_variance_are_reproducible(self):
        stylometry = analyze_stylometry(
            {
                "a.txt": "bey und.",
                "b.txt": "bey der der.",
                "c.txt": "und in in in.",
                "d.txt": "mit zu.",
            }
        )
        first = analyze_pca(stylometry)
        second = analyze_pca(stylometry)

        self.assertEqual(first, second)
        self.assertEqual(first["components"], ["PC1", "PC2"])
        self.assertEqual(first["component_count"], 2)
        self.assertGreater(first["explained_variance_ratio"][0], 0)
        self.assertLessEqual(sum(first["explained_variance_ratio"]), 1.0)
        self.assertEqual(set(first["scores"]), set(stylometry["documents"]))
        self.assertTrue(all(len(point) == 2 for point in first["scores"].values()))

    def test_two_documents_and_constant_features_have_zero_second_axis(self):
        result = calculate_pca(
            {
                "documents": ["a.txt", "b.txt"],
                "feature_names": ["x"],
                "matrix": [[1.0], [3.0]],
                "feature_set": "test",
            }
        )

        self.assertEqual(result["component_count"], 1)
        self.assertEqual(result["explained_variance_ratio"], [1.0, 0.0])
        self.assertEqual(result["scores"]["a.txt"][1], 0.0)
        self.assertEqual(result["scores"]["b.txt"][1], 0.0)

    def test_single_document_returns_defined_zero_coordinates(self):
        result = calculate_pca(
            {
                "documents": ["only.txt"],
                "feature_names": ["x"],
                "matrix": [[2.0]],
                "feature_set": "test",
            }
        )

        self.assertEqual(result["component_count"], 0)
        self.assertEqual(result["explained_variance_ratio"], [0.0, 0.0])
        self.assertEqual(result["scores"], {"only.txt": [0.0, 0.0]})


class PcaVisualizationTests(unittest.TestCase):
    def test_svg_labels_every_text_and_displays_component_variance(self):
        pca = {
            "documents": ["one & two.txt", "second.txt"],
            "scores": {"one & two.txt": [-1.0, 0.25], "second.txt": [1.0, -0.25]},
            "explained_variance_ratio": [0.75, 0.25],
            "feature_set": "function_words",
        }
        with tempfile.TemporaryDirectory() as temporary:
            output = render_pca_svg(pca, Path(temporary) / "plot.svg")
            svg = output.read_text(encoding="utf-8")

        self.assertIn("one &amp; two.txt", svg)
        self.assertIn("second.txt", svg)
        self.assertIn("PC1 (75.0% erklärte Varianz)", svg)
        self.assertIn("PC2 (25.0% erklärte Varianz)", svg)
        self.assertIn("keine Aussage über Autorschaft", svg)


if __name__ == "__main__":
    unittest.main()
