import json
import tempfile
import unittest
from pathlib import Path

from src.function_words import FUNCTION_WORD_GROUPS
from src.linguistic_analysis import (
    analyze_corpus,
    analyze_text,
    save_corpus_analysis,
    split_sentences,
    tokenize_words,
)


class TokenizationTests(unittest.TestCase):
    def test_keeps_historical_letters_diacritics_and_internal_apostrophes(self):
        text = "ſaͤtze Reiſe John's ‘Bey’ 1778"

        self.assertEqual(
            tokenize_words(text),
            ["ſaͤtze", "Reiſe", "John's", "Bey"],
        )

    def test_does_not_modernize_or_discard_unusual_forms(self):
        metrics = analyze_text("ſeyn daß bey Thun Xyzzq.")
        forms = {entry["word"] for entry in metrics["most_frequent_word_forms"]}

        self.assertEqual(metrics["word_count"], 5)
        self.assertTrue({"ſeyn", "daß", "bey", "Thun", "Xyzzq"}.issubset(forms))


class FunctionWordInventoryTests(unittest.TestCase):
    def test_function_word_groups_are_disjoint(self):
        memberships = {}
        for group, words in FUNCTION_WORD_GROUPS.items():
            for word in words:
                memberships.setdefault(word, []).append(group)

        overlaps = {word: groups for word, groups in memberships.items() if len(groups) > 1}
        self.assertEqual(overlaps, {})

    def test_long_s_variants_match_inventory_without_changing_surface_tokens(self):
        metrics = analyze_text("ſeyn iſt ſich dieſe Reiſe")
        distribution = metrics["function_word_distribution"]
        frequencies = {entry["word"]: entry["count"] for entry in distribution["frequencies"]}

        self.assertEqual(distribution["token_count"], 4)
        self.assertEqual(frequencies["seyn"], 1)
        self.assertEqual(frequencies["ist"], 1)
        self.assertEqual(frequencies["sich"], 1)
        self.assertEqual(frequencies["diese"], 1)
        forms = {entry["word"] for entry in metrics["most_frequent_word_forms"]}
        self.assertIn("ſeyn", forms)
        self.assertIn("Reiſe", forms)


class MetricTests(unittest.TestCase):
    def test_hand_calculable_metrics(self):
        metrics = analyze_text("Daß bey ſeyn. Daß Nacht!")

        self.assertEqual(metrics["word_count"], 5)
        self.assertEqual(metrics["sentence_count"], 2)
        self.assertEqual(metrics["average_sentence_length_words"], 2.5)
        self.assertEqual(metrics["average_word_length_letters"], 3.6)
        self.assertEqual(metrics["type_count"], 4)
        self.assertEqual(metrics["type_token_ratio"], 0.8)
        self.assertEqual(metrics["hapax_legomena_count"], 3)
        self.assertEqual(metrics["hapax_type_share"], 0.75)
        self.assertEqual(metrics["hapax_token_share"], 0.6)

        function_words = metrics["function_word_distribution"]
        self.assertEqual(function_words["token_count"], 4)
        self.assertEqual(function_words["share_of_words"], 0.8)
        self.assertEqual(function_words["groups"]["auxiliary_and_modal_verbs"]["token_count"], 1)
        self.assertEqual(function_words["groups"]["conjunctions"]["token_count"], 2)
        self.assertEqual(function_words["groups"]["prepositions"]["token_count"], 1)

    def test_word_and_surface_form_frequencies_are_distinct(self):
        metrics = analyze_text("Daß daſ? Daß daß")
        words = metrics["most_frequent_words"]
        forms = metrics["most_frequent_word_forms"]

        self.assertEqual(words[0], {"word": "daß", "count": 3, "share_of_words": 0.75})
        form_counts = {entry["word"]: entry["count"] for entry in forms}
        self.assertEqual(form_counts["daß"], 1)
        self.assertEqual(form_counts["Daß"], 2)

    def test_abbreviations_do_not_create_sentence_boundaries(self):
        sentences = split_sentences("Dr. Müller reist. Danach liest er u. a. Briefe.")

        self.assertEqual(len(sentences), 2)
        self.assertEqual([len(sentence) for sentence in sentences], [3, 6])

    def test_empty_and_unpunctuated_text_are_defined(self):
        empty = analyze_text("")
        fragment = analyze_text("ein unvollständiger Text")

        self.assertEqual(empty["word_count"], 0)
        self.assertEqual(empty["sentence_count"], 0)
        self.assertEqual(empty["type_token_ratio"], 0.0)
        self.assertEqual(fragment["sentence_count"], 1)
        self.assertEqual(fragment["average_sentence_length_words"], 3.0)

    def test_frequency_ties_are_sorted_deterministically(self):
        metrics = analyze_text("bey daẞ aber")

        self.assertEqual(
            [entry["word"] for entry in metrics["most_frequent_words"]],
            ["aber", "bey", "daß"],
        )

    def test_noun_candidates_exclude_sentence_initials_and_function_words(self):
        metrics = analyze_text(
            "Berlin reist. Die Reise führt nach Berlin. Die Reise ist schön."
        )
        candidates = metrics["most_frequent_noun_candidates"]

        self.assertEqual(
            candidates,
            [
                {"word": "berlin", "count": 2, "share_of_words": 0.181818},
                {"word": "reise", "count": 2, "share_of_words": 0.181818},
            ],
        )

    def test_noun_candidate_limit_and_empty_input(self):
        text = "Das ist A und B. Danach sieht C."
        metrics = analyze_text(text, top_n=2)

        self.assertLessEqual(len(metrics["most_frequent_noun_candidates"]), 2)
        self.assertEqual(analyze_text("")["most_frequent_noun_candidates"], [])

    def test_noun_candidates_exclude_short_ocr_fragments_and_contractions(self):
        metrics = analyze_text(
            "Das ist im Ort. Die Reise kommt vom Land. Der Ort ist im Land."
        )
        words = {
            item["word"] for item in metrics["most_frequent_noun_candidates"]
        }

        self.assertNotIn("im", words)
        self.assertNotIn("vom", words)
        self.assertNotIn("a", words)
        self.assertIn("ort", words)
        self.assertIn("land", words)

    def test_top_n_must_not_be_negative(self):
        with self.assertRaises(ValueError):
            analyze_text("Text.", top_n=-1)


class CorpusAnalysisTests(unittest.TestCase):
    def test_corpus_json_is_ordered_structured_and_reproducible(self):
        with tempfile.TemporaryDirectory() as temporary:
            input_dir = Path(temporary) / "texts"
            input_dir.mkdir()
            (input_dir / "b.txt").write_text("daß bey.", encoding="utf-8")
            (input_dir / "a.txt").write_text("ſeyn auch.", encoding="utf-8")
            output = Path(temporary) / "results.json"

            save_corpus_analysis(input_dir, output)
            first = output.read_bytes()
            save_corpus_analysis(input_dir, output)
            second = output.read_bytes()

        self.assertEqual(first, second)
        data = json.loads(first)
        self.assertEqual(data["schema_version"], "1.0")
        self.assertEqual([item["file"] for item in data["documents"]], ["a.txt", "b.txt"])
        self.assertEqual(data["documents"][0]["metrics"]["word_count"], 2)
        self.assertIn("function_word_list_version", data["configuration"])

    def test_empty_corpus_is_reported(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(FileNotFoundError):
                analyze_corpus(Path(temporary))


if __name__ == "__main__":
    unittest.main()