"""Conservative, reproducible preprocessing for VoyageStylo OCR texts."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"

JAGEMANN_FILE = "christian_joseph_jagemann_briefe_italien_1778.txt"
SPARRMAN_FILE = "anders_sparrman_reise_vorgebirge_1784.txt"
MEINERS_FILE = "christoph_meiners_briefe_schweiz_1791.txt"

_NUMBER_LINE = re.compile(r"^\s*(\d{1,4})\s*$")
_PAGE_BREAK_HYPHEN = "\u2e17"


def _letter_count(value: str) -> int:
    return len(re.findall(r"[^\W\d_]", value, flags=re.UNICODE))


def _nearest_nonempty(lines: list[str], index: int, direction: int) -> str:
    cursor = index + direction
    while 0 <= cursor < len(lines):
        value = lines[cursor].strip()
        if value:
            return value
        cursor += direction
    return ""


def _page_number_lines(lines: list[str], minimum_run: int = 5) -> set[int]:
    """Find only long increasing runs of stand-alone numbers between prose."""
    candidates: list[tuple[int, int]] = []
    for index, line in enumerate(lines):
        match = _NUMBER_LINE.fullmatch(line)
        if not match:
            continue
        has_prose_neighbor = any(
            _letter_count(neighbor) >= 15
            for neighbor in (
                _nearest_nonempty(lines, index, -1),
                _nearest_nonempty(lines, index, 1),
            )
        )
        if has_prose_neighbor:
            candidates.append((index, int(match.group(1))))

    removed: set[int] = set()
    run: list[tuple[int, int]] = []
    for candidate in candidates:
        if run and candidate[1] != run[-1][1] + 1:
            if len(run) >= minimum_run:
                removed.update(index for index, _ in run)
            run = []
        run.append(candidate)

    if len(run) >= minimum_run:
        removed.update(index for index, _ in run)
    return removed


def _strip_known_scan_material(lines: list[str], filename: str) -> list[str]:
    lines = list(lines)

    if filename == JAGEMANN_FILE:
        has_google_cover = (
            bool(lines)
            and lines[0].strip() == "Google"
            and any("This is a digital copy" in line for line in lines[:20])
        )
        if has_google_cover:
            notice_end = next(
                (
                    index
                    for index, line in enumerate(lines[:150])
                    if line.strip().startswith("Den gesamten Buch")
                ),
                None,
            )
            if notice_end is not None:
                lines = lines[notice_end + 1 :]

        stanford_index = next(
            (
                index
                for index, line in enumerate(lines)
                if index >= int(len(lines) * 0.95)
                and line.strip().startswith("STANFORD")
                and any("DATE DUE" in later for later in lines[index:])
            ),
            None,
        )
        if stanford_index is not None:
            lines = lines[:stanford_index]

    elif filename == SPARRMAN_FILE:
        catalog_index = next(
            (
                index
                for index, line in enumerate(lines)
                if index >= int(len(lines) * 0.95)
                and "Bamberg, Staatsbibliothek --" in line
                and any(
                    marker in later
                    for later in lines[index:]
                    for marker in (
                        "urn:nbn:de:bvb:",
                        "um:nbn.de:bvb:",
                        "018 14633965-001",
                    )
                )
            ),
            None,
        )
        if catalog_index is not None:
            lines = lines[:catalog_index]

    elif filename == MEINERS_FILE:
        digital_library_index = next(
            (
                index
                for index, line in enumerate(lines)
                if index >= int(len(lines) * 0.95)
                and "Digitale Bibliothek" in line
                and any(
                    marker in later
                    for later in lines[index:]
                    for marker in (
                        "urn:nbn:de:bvb:",
                        "um:nbn.de:bvb:",
                        "018 80023479-001",
                    )
                )
            ),
            None,
        )
        if digital_library_index is not None:
            mdz_index = digital_library_index - 1
            if mdz_index >= 0 and "MDZ" in lines[mdz_index]:
                lines[mdz_index] = lines[mdz_index].split("MDZ", 1)[0].rstrip()
                lines = lines[: mdz_index + 1]

    return lines


def _reflow_paragraphs(lines: list[str]) -> str:
    paragraphs: list[str] = []
    current: list[str] = []

    def flush() -> None:
        if current:
            paragraphs.append(" ".join(current))
            current.clear()

    for line in lines:
        value = line.strip()
        if not value:
            flush()
            continue

        if (
            current
            and current[-1].endswith(_PAGE_BREAK_HYPHEN)
            and value[0].islower()
        ):
            current[-1] = current[-1][:-1] + value
        else:
            current.append(value)

    flush()
    return "\n\n".join(paragraphs) + ("\n" if paragraphs else "")


def preprocess_text(text: str, filename: str = "") -> str:
    """Return a processed copy without changing source orthography."""
    normalized_lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    lines = _strip_known_scan_material(normalized_lines, Path(filename).name)
    page_numbers = _page_number_lines(lines)
    lines = [line for index, line in enumerate(lines) if index not in page_numbers]
    return _reflow_paragraphs(lines)


def process_corpus(raw_dir: Path = RAW_DIR, processed_dir: Path = PROCESSED_DIR) -> list[Path]:
    """Write one deterministic UTF-8 processed copy per raw ``.txt`` file."""
    raw_dir = Path(raw_dir)
    processed_dir = Path(processed_dir)
    sources = sorted(raw_dir.glob("*.txt"), key=lambda path: path.name)
    if not sources:
        raise FileNotFoundError(f"No .txt corpus files found in {raw_dir}")

    processed_dir.mkdir(parents=True, exist_ok=True)
    outputs: list[Path] = []
    for source in sources:
        text = source.read_bytes().decode("utf-8")
        processed = preprocess_text(text, source.name)
        target = processed_dir / source.name
        with target.open("w", encoding="utf-8", newline="\n") as output:
            output.write(processed)
        outputs.append(target)
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, default=RAW_DIR)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DIR)
    args = parser.parse_args()
    outputs = process_corpus(args.raw_dir, args.processed_dir)
    print(f"Processed {len(outputs)} text files into {args.processed_dir}")


if __name__ == "__main__":
    main()