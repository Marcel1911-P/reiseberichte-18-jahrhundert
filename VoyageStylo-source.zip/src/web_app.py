"""Local VoyageStylo web application using only the Python standard library."""

from __future__ import annotations

import argparse
import json
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

if __package__:
    from .linguistic_analysis import tokenize_words
    from .pca_visualization import analyze_pca
    from .stylometry import PROCESSED_DIR, analyze_stylometry
else:
    from linguistic_analysis import tokenize_words
    from pca_visualization import analyze_pca
    from stylometry import PROCESSED_DIR, analyze_stylometry


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_METADATA_PATH = PROJECT_ROOT / "data" / "metadata" / "source_manifest.json"
WEB_DIR = PROJECT_ROOT / "web"
MAX_REQUEST_BYTES = 16_384
MAX_DOCUMENTS = 20
FEATURE_SETS = frozenset(("function_words", "tfidf"))
_TRAVEL_PERIOD = re.compile(
    r"(?:Jahr(?:en)?|years?)\s+(\d{4})\s+(?:bis|to|-)\s+(\d{4})",
    re.IGNORECASE,
)


def _title_metadata(title: str) -> tuple[str | None, str | None]:
    destination = None
    if "nach Arabien" in title:
        destination = "Arabien und umliegende Länder (laut Titel)"
    elif "Vorgebirge der guten Hoffnung" in title:
        destination = "Vorgebirge der Guten Hoffnung und südliche Polarländer (laut Titel)"
    elif "um die Welt" in title:
        destination = "Weltumsegelung (laut Titel)"
    elif "Italien" in title:
        destination = "Italien (laut Titel)"
    elif "Schweiz" in title:
        destination = "Schweiz (laut Titel)"

    period_match = _TRAVEL_PERIOD.search(title)
    period = (
        f"{period_match.group(1)}–{period_match.group(2)} (laut Titel)"
        if period_match
        else None
    )
    return destination, period


def load_corpus(
    processed_dir: Path = PROCESSED_DIR,
    metadata_path: Path = DEFAULT_METADATA_PATH,
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    """Load metadata and processed texts by their manifest-controlled filename."""
    processed_dir = Path(processed_dir)
    metadata_path = Path(metadata_path)
    manifest = json.loads(metadata_path.read_text(encoding="utf-8"))
    entries = manifest.get("documents") if isinstance(manifest, dict) else None
    if not isinstance(entries, list):
        raise ValueError(f"Corpus manifest has no documents list: {metadata_path}")

    metadata: dict[str, dict[str, Any]] = {}
    texts: dict[str, str] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Corpus manifest contains an invalid document entry")
        filename = entry.get("file")
        if (
            not isinstance(filename, str)
            or not filename
            or Path(filename).name != filename
            or not filename.endswith(".txt")
        ):
            raise ValueError(f"Invalid corpus filename in manifest: {filename!r}")
        if filename in metadata:
            raise ValueError(f"Duplicate corpus filename in manifest: {filename}")

        path = processed_dir / filename
        if not path.is_file():
            raise FileNotFoundError(f"Processed corpus text not found: {path}")
        text = path.read_bytes().decode("utf-8")
        title = entry.get("title")
        if not isinstance(title, str) or not title:
            raise ValueError(f"Document title is missing in manifest: {filename}")
        destination, travel_period = _title_metadata(title)
        metadata[filename] = {
            "file": filename,
            "title": title,
            "author": entry.get("creator") or "Nicht angegeben",
            "publication_year": entry.get("publication_year"),
            "travel_period": travel_period,
            "destination": destination,
            "metadata_note": "Reiseziel und Reisezeitraum werden nur angezeigt, wenn sie im Quellentitel ausdrücklich genannt sind.",
        }
        texts[filename] = text

    if not metadata:
        raise ValueError("Corpus manifest does not list any documents")
    return metadata, texts


def corpus_overview(
    processed_dir: Path = PROCESSED_DIR,
    metadata_path: Path = DEFAULT_METADATA_PATH,
) -> dict[str, Any]:
    """Return manifest metadata and word counts for the prepared corpus."""
    metadata, texts = load_corpus(processed_dir, metadata_path)
    documents = []
    for filename, item in metadata.items():
        documents.append(
            {
                **item,
                "word_count": len(tokenize_words(texts[filename])),
            }
        )
    return {"documents": documents}


def analyze_selection(
    filenames: list[str],
    feature_set: str = "function_words",
    processed_dir: Path = PROCESSED_DIR,
    metadata_path: Path = DEFAULT_METADATA_PATH,
) -> dict[str, Any]:
    """Analyze only validated selected texts with existing project functions."""
    if not isinstance(filenames, list) or not filenames:
        raise ValueError("Select at least one document")
    if len(filenames) > MAX_DOCUMENTS:
        raise ValueError(f"Select no more than {MAX_DOCUMENTS} documents")
    if any(not isinstance(name, str) for name in filenames):
        raise ValueError("Document selections must be filenames")
    if len(set(filenames)) != len(filenames):
        raise ValueError("A document may be selected only once")
    if feature_set not in FEATURE_SETS:
        raise ValueError("Unknown PCA feature set")

    metadata, corpus_texts = load_corpus(processed_dir, metadata_path)
    unknown = sorted(set(filenames) - corpus_texts.keys())
    if unknown:
        raise ValueError(f"Unknown corpus document: {', '.join(unknown)}")

    documents = {name: corpus_texts[name] for name in sorted(filenames)}
    stylometry = analyze_stylometry(documents)
    metrics = stylometry["descriptive_features"]
    pca = analyze_pca(stylometry, feature_set)
    return {
        "documents": [
            {
                **metadata[name],
                "metrics": metrics[name],
                "stylometric_features": stylometry["descriptive_features"][name],
            }
            for name in stylometry["documents"]
        ],
        "stylometry": stylometry,
        "pca": pca,
    }


def _json_bytes(payload: Any) -> bytes:
    return json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")


def create_server(
    host: str = "127.0.0.1",
    port: int = 8000,
    processed_dir: Path = PROCESSED_DIR,
    metadata_path: Path = DEFAULT_METADATA_PATH,
    web_dir: Path = WEB_DIR,
) -> ThreadingHTTPServer:
    """Create a local-only HTTP server for the UI and analysis endpoints."""
    processed_dir = Path(processed_dir).resolve()
    metadata_path = Path(metadata_path).resolve()
    web_dir = Path(web_dir).resolve()

    class VoyageStyloHandler(BaseHTTPRequestHandler):
        server_version = "VoyageStylo/1.0"

        def _send(self, status: int, content_type: str, body: bytes) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _send_json(self, status: int, payload: Any) -> None:
            self._send(
                status,
                "application/json; charset=utf-8",
                _json_bytes(payload),
            )

        def do_GET(self) -> None:
            route = urlsplit(self.path).path
            if route == "/favicon.ico":
                self.send_response(204)
                self.end_headers()
                return
            if route == "/api/corpus":
                try:
                    self._send_json(200, corpus_overview(processed_dir, metadata_path))
                except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as error:
                    self._send_json(500, {"error": str(error)})
                return
            if route not in ("/", "/index.html", "/app.js", "/styles.css"):
                self._send_json(404, {"error": "Not found"})
                return

            filename = (
                "index.html"
                if route in ("/", "/index.html")
                else route[1:]
            )
            content_types = {
                "index.html": "text/html; charset=utf-8",
                "app.js": "text/javascript; charset=utf-8",
                "styles.css": "text/css; charset=utf-8",
            }
            try:
                body = (web_dir / filename).read_bytes()
            except OSError as error:
                self._send_json(500, {"error": f"Could not read web asset: {error}"})
                return
            self._send(200, content_types[filename], body)

        def do_POST(self) -> None:
            if urlsplit(self.path).path != "/api/analyze":
                self._send_json(404, {"error": "Not found"})
                return
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self._send_json(400, {"error": "Invalid Content-Length"})
                return
            if content_length < 1 or content_length > MAX_REQUEST_BYTES:
                self._send_json(413, {"error": "Request body is empty or too large"})
                return
            try:
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Request must be a JSON object")
                result = analyze_selection(
                    payload.get("documents"),
                    payload.get("feature_set", "function_words"),
                    processed_dir,
                    metadata_path,
                )
                self._send_json(200, result)
            except (UnicodeError, json.JSONDecodeError, TypeError, ValueError) as error:
                self._send_json(400, {"error": str(error)})
            except (OSError, ArithmeticError) as error:
                self._send_json(500, {"error": str(error)})

        def log_message(self, format: str, *args: Any) -> None:
            super().log_message(format, *args)

    return ThreadingHTTPServer((host, port), VoyageStyloHandler)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if args.host not in ("127.0.0.1", "localhost", "::1"):
        parser.error("VoyageStylo binds to localhost only")

    server = create_server(args.host, args.port)
    print(f"VoyageStylo is available at http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping VoyageStylo.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
