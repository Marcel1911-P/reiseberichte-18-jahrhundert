"""Transparent, local function-word inventory for historical German texts."""


FUNCTION_WORD_GROUPS = {
    "articles_and_determiners": frozenset(
        "der die das des dem den ein eine einer eines einem einen kein keine keiner "
        "keines keinem keinen dieser diese dieses diesen diesem jener jene jenes "
        "jenen jenem mancher manche manches manchen manchem welcher welche welches "
        "welchen welchem alle aller allem allen alles beide beider beiden jeder jede "
        "jedes jedem jeden solcher solche solches solchen solchem mein meine "
        "meines meinem meinen dein deine deines deinem deinen seine seiner seines "
        "seinem seinen ihre ihrer ihres ihrem ihren unsre unsers unsrem unsern unseres "
        "eure eurer eures eurem euren".split()
    ),
    "pronouns": frozenset(
        "ich mich mir meiner du dich dir deiner er ihn ihm sie ihnen ihr es wir uns "
        "euch unser euer man sich wer wen wem wessen was jemand niemand etwas nichts "
        "einander derselbe dieselbe dasselbe".split()
    ),
    "prepositions": frozenset(
        "ab an auf aus ausser außer bei bey beym bis biß durch für gegen gen gegenüber "
        "hinter in innerhalb außerhalb ausserhalb mit nach neben ohne ohn seit samt "
        "statt trotz über um umb unter von vor während wegen wider zu zwischen".split()
    ),
    "conjunctions": frozenset(
        "und oder aber sondern denn doch jedoch daß dass ob weil wenn wann als wie "
        "indem nachdem bevor ehe damit sofern obwohl obgleich gleichwohl sobald solange "
        "sowie".split()
    ),
    "auxiliary_and_modal_verbs": frozenset(
        "sein seyn bin bist ist sind seid sei seyst seyen sey seyn war warst waren "
        "ward wurden gewesen haben habe hab hast hat haben habt hatte hattest hatten "
        "gehabt werden werde wirst wird werdet ward wurde wurdest wurden worden geworden "
        "können koennen kann kannst konnte konntest konnten könnt moegen mögen mag "
        "mochte mochten duerfen dürfen darf durfte durften muessen müssen muss musst "
        "musste mussten sollen soll sollst sollte sollten wollen will willst wollte "
        "wollte wollten duerfte dürfte".split()
    ),
    "particles": frozenset(
        "nicht nur auch schon noch sehr wohl ja eben etwa bloß bloss allein erst selbst "
        "nun gerade fast wieder bereits recht mehr weniger zugleich".split()
    ),
}

FUNCTION_WORD_TO_GROUP = {
    word: group
    for group, words in FUNCTION_WORD_GROUPS.items()
    for word in words
}


def function_word_key(word: str) -> str | None:
    """Return the inventory key, treating long s as s only for list lookup."""
    if word in FUNCTION_WORD_TO_GROUP:
        return word
    candidate = word.replace("ſ", "s")
    return candidate if candidate in FUNCTION_WORD_TO_GROUP else None


FUNCTION_WORD_LIST_VERSION = "voyagestylo-de-historical-v2"