"""Reproducible descriptive metrics for prepared VoyageStylo texts."""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Iterable

if __package__:
    from .function_words import (
        FUNCTION_WORD_GROUPS,
        FUNCTION_WORD_LIST_VERSION,
        FUNCTION_WORD_TO_GROUP,
        function_word_key,
    )
else:
    from function_words import (
        FUNCTION_WORD_GROUPS,
        FUNCTION_WORD_LIST_VERSION,
        FUNCTION_WORD_TO_GROUP,
        function_word_key,
    )


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
DEFAULT_OUTPUT = PROCESSED_DIR / "linguistic_metrics.json"
SCHEMA_VERSION = "1.0"
DEFAULT_TOP_N = 20

# Periods after these tokens are treated as abbreviation punctuation, not a
# sentence boundary. This deliberately small rule is documented and testable.
_ABBREVIATIONS = frozenset(
    "dr prof hr fr nr no bd bde th kap fig vgl usw bzw resp ca etc u a s w z b d h"
    .split()
)
_SENTENCE_END = re.compile(r"[.!?…]+(?=\s|$)")
_APOSTROPHES = frozenset(("'", "’"))
_NOUN_CANDIDATE_FUNCTION_WORDS = frozenset(
    "am ans aufs beim durchs fürs im ins ums vom vorm zum zur".split()
)


def tokenize_words(text: str) -> list[str]:
    """Return runs of Unicode letters, retaining combining marks and apostrophes.

    Digits and punctuation delimit tokens. Internal straight or curly
    apostrophes are retained only when followed by a Unicode letter.
    """
    words: list[str] = []
    current: list[str] = []

    def flush() -> None:
        if current:
            words.append("".join(current))
            current.clear()

    for index, character in enumerate(text):
        category = unicodedata.category(character)
        if category.startswith("L"):
            current.append(character)
        elif category.startswith("M") and current:
            current.append(character)
        elif (
            character in _APOSTROPHES
            and current
            and index + 1 < len(text)
            and unicodedata.category(text[index + 1]).startswith("L")
        ):
            current.append(character)
        else:
            flush()

    flush()
    return words


def _preceding_word(text: str, end_index: int) -> str:
    index = end_index - 1
    while index >= 0 and unicodedata.category(text[index]).startswith("M"):
        index -= 1
    end = index + 1
    while index >= 0:
        category = unicodedata.category(text[index])
        if category.startswith("L") or category.startswith("M"):
            index -= 1
        else:
            break
    return text[index + 1 : end]


def _is_abbreviation_period(text: str, start_index: int, punctuation: str) -> bool:
    if any(character in punctuation for character in "!?…"):
        return False
    return _preceding_word(text, start_index).lower() in _ABBREVIATIONS


def split_sentences(text: str) -> list[list[str]]:
    """Split into sentence token lists using punctuation plus paragraph breaks.

    Unpunctuated, non-empty paragraph fragments count as sentences. Periods
    after the explicit abbreviation inventory are ignored as boundaries.
    """
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    sentences: list[list[str]] = []

    for paragraph in re.split(r"\n\s*\n+", normalized):
        start = 0
        for match in _SENTENCE_END.finditer(paragraph):
            if _is_abbreviation_period(paragraph, match.start(), match.group()):
                continue
            tokens = tokenize_words(paragraph[start : match.end()])
            if tokens:
                sentences.append(tokens)
            start = match.end()

        trailing_tokens = tokenize_words(paragraph[start:])
        if trailing_tokens:
            sentences.append(trailing_tokens)

    return sentences


def _ratio(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 6) if denominator else 0.0


def _frequencies(counter: Counter[str], total: int, limit: int) -> list[dict[str, int | float | str]]:
    return [
        {
            "word": word,
            "count": count,
            "share_of_words": _ratio(count, total),
        }
        for word, count in sorted(counter.items(), key=lambda item: (-item[1], item[0]))[:limit]
    ]


def _letter_length(word: str) -> int:
    return sum(unicodedata.category(character).startswith("L") for character in word)


def _function_word_metrics(words: Iterable[str], total_words: int) -> dict[str, object]:
    counts: Counter[str] = Counter()
    groups: dict[str, Counter[str]] = {
        group: Counter() for group in FUNCTION_WORD_GROUPS
    }

    for word in words:
        key = function_word_key(word.lower())
        if key is not None:
            group = FUNCTION_WORD_TO_GROUP[key]
            counts[key] += 1
            groups[group][key] += 1

    function_word_count = sum(counts.values())
    return {
        "token_count": function_word_count,
        "share_of_words": _ratio(function_word_count, total_words),
        "frequencies": _frequencies(counts, total_words, len(counts)),
        "groups": {
            group: {
                "token_count": sum(group_counts.values()),
                "share_of_words": _ratio(sum(group_counts.values()), total_words),
                "frequencies": _frequencies(
                    group_counts, total_words, len(group_counts)
                ),
            }
            for group, group_counts in groups.items()
        },
    }


def _noun_candidate_frequencies(
    words: list[str], sentences: list[list[str]], top_n: int
) -> list[dict[str, int | float | str]]:
    """Rank capitalized non-function-word candidates, excluding sentence starts."""
    candidates = {
        word.lower()
        for sentence in sentences
        for word in sentence[1:]
        if len(word) >= 3
        and word[0].isupper()
        and function_word_key(word.lower()) is None
        and word.lower() not in _NOUN_CANDIDATE_FUNCTION_WORDS
    }
    candidate_counts = Counter(word.lower() for word in words if word.lower() in candidates)
    return _frequencies(candidate_counts, len(words), top_n)


def analyze_text(text: str, top_n: int = DEFAULT_TOP_N) -> dict[str, object]:
    """Calculate transparent metrics without modifying or modernizing ``text``."""
    if top_n < 0:
        raise ValueError("top_n must be greater than or equal to zero")

    words = tokenize_words(text)
    normalized_words = [word.lower() for word in words]
    type_counts = Counter(normalized_words)
    surface_counts = Counter(words)
    sentences = split_sentences(text)
    hapax_count = sum(count == 1 for count in type_counts.values())
    total_letters = sum(_letter_length(word) for word in words)
    function_words = _function_word_metrics(words, len(words))

    return {
        "word_count": len(words),
        "sentence_count": len(sentences),
        "average_sentence_length_words": round(
            len(words) / len(sentences), 6
        )
        if sentences
        else 0.0,
        "average_word_length_letters": round(total_letters / len(words), 6)
        if words
        else 0.0,
        "type_count": len(type_counts),
        "type_token_ratio": _ratio(len(type_counts), len(words)),
        "hapax_legomena_count": hapax_count,
        "hapax_type_share": _ratio(hapax_count, len(type_counts)),
        "hapax_token_share": _ratio(hapax_count, len(words)),
        "most_frequent_words": _frequencies(type_counts, len(words), top_n),
        "most_frequent_word_forms": _frequencies(surface_counts, len(words), top_n),
        "most_frequent_noun_candidates": _noun_candidate_frequencies(
            words, sentences, top_n
        ),
        "function_word_distribution": function_words,
    }


def _analysis_manifest(top_n: int) -> dict[str, object]:
    return {
        "schema_version": SCHEMA_VERSION,
        "configuration": {
            "input_format": "UTF-8 processed .txt files",
            "top_n": top_n,
            "function_word_list_version": FUNCTION_WORD_LIST_VERSION,
            "tokenizer": "Unicode letter runs with combining marks; internal apostrophes retained; digits delimit tokens",
            "case_aggregation": "str.lower() for frequency aggregation; no casefold, general spelling normalization, stemming, or lemmatization",
            "sentence_segmentation": "terminal .!?… punctuation, except explicit abbreviation tokens; blank paragraphs and unpunctuated final fragments are sentence units",
            "function_words": "versioned local inventory lookup with long-s mapped to s only for membership; ambiguous forms are not context-disambiguated",
        },
    }


def analyze_corpus(
    processed_dir: Path = PROCESSED_DIR, top_n: int = DEFAULT_TOP_N
) -> dict[str, object]:
    """Analyze all processed text files in deterministic filename order."""
    if top_n < 0:
        raise ValueError("top_n must be greater than or equal to zero")

    processed_dir = Path(processed_dir)
    files = sorted(processed_dir.glob("*.txt"), key=lambda path: path.name)
    if not files:
        raise FileNotFoundError(f"No processed .txt files found in {processed_dir}")

    documents = []
    for path in files:
        text = path.read_bytes().decode("utf-8")
        documents.append({"file": path.name, "metrics": analyze_text(text, top_n)})

    result = _analysis_manifest(top_n)
    result["documents"] = documents
    return result


def save_corpus_analysis(
    processed_dir: Path = PROCESSED_DIR,
    output_path: Path = DEFAULT_OUTPUT,
    top_n: int = DEFAULT_TOP_N,
) -> Path:
    """Write deterministic, UTF-8 JSON that can be consumed by the web UI."""
    result = analyze_corpus(processed_dir, top_n)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
    output_path.write_text(serialized + "\n", encoding="utf-8", newline="\n")
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=PROCESSED_DIR)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--top-n", type=int, default=DEFAULT_TOP_N)
    args = parser.parse_args()
    output = save_corpus_analysis(args.input_dir, args.output, args.top_n)
    print(f"Analyzed texts; results written to {output}")


if __name__ == "__main__":
    main()