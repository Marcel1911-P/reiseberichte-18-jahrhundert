"""Exploratory PCA plot of VoyageStylo stylometric feature vectors."""

from __future__ import annotations

import argparse
import html
import math
from pathlib import Path
from typing import Mapping

if __package__:
    from .stylometry import PROCESSED_DIR, analyze_corpus
else:
    from stylometry import PROCESSED_DIR, analyze_corpus


DEFAULT_OUTPUT = PROCESSED_DIR / "stylometry_pca.svg"
FEATURE_SETS = ("function_words", "tfidf")
COMPONENT_COUNT = 2


def prepare_pca_data(
    stylometry: Mapping[str, object],
    feature_set: str = "function_words",
) -> dict[str, object]:
    """Extract a dense, consistently ordered document-feature matrix."""
    if feature_set not in FEATURE_SETS:
        raise ValueError(f"feature_set must be one of {FEATURE_SETS}")

    documents = stylometry.get("documents")
    if not isinstance(documents, list) or any(
        not isinstance(name, str) or not name for name in documents
    ):
        raise ValueError("stylometry must contain a list of document names")
    if len(set(documents)) != len(documents):
        raise ValueError("document names must be unique")

    block = stylometry.get(feature_set)
    if not isinstance(block, Mapping):
        raise ValueError(f"stylometry must contain a {feature_set} feature block")
    vectors = block.get("vectors")
    if not isinstance(vectors, Mapping):
        raise ValueError(f"{feature_set} must contain document feature vectors")

    feature_names = sorted(
        {
            feature
            for name in documents
            for feature in (
                vectors.get(name, {}).keys()
                if isinstance(vectors.get(name), Mapping)
                else ()
            )
        }
    )
    matrix: list[list[float]] = []
    for name in documents:
        vector = vectors.get(name)
        if not isinstance(vector, Mapping):
            raise ValueError(f"Missing {feature_set} vector for {name!r}")
        row = []
        for feature in feature_names:
            value = vector.get(feature, 0.0)
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(f"Feature {feature!r} for {name!r} must be numeric")
            value = float(value)
            if not math.isfinite(value):
                raise ValueError(f"Feature {feature!r} for {name!r} is not finite")
            row.append(value)
        matrix.append(row)

    if not feature_names:
        raise ValueError(f"No {feature_set} features are available")
    return {
        "documents": list(documents),
        "feature_names": feature_names,
        "matrix": matrix,
        "feature_set": feature_set,
    }


def _jacobi_eigen(
    matrix: list[list[float]],
) -> tuple[list[float], list[list[float]]]:
    """Return eigenvalues and column eigenvectors for a symmetric matrix."""
    size = len(matrix)
    values = [row[:] for row in matrix]
    vectors = [[float(row == column) for column in range(size)] for row in range(size)]
    tolerance = 1e-14
    max_iterations = max(1, 50 * size * size)

    for _ in range(max_iterations):
        pivot_row = 0
        pivot_column = 0
        largest = 0.0
        for row in range(size):
            for column in range(row + 1, size):
                magnitude = abs(values[row][column])
                if magnitude > largest:
                    largest = magnitude
                    pivot_row, pivot_column = row, column
        if largest <= tolerance:
            break

        p, q = pivot_row, pivot_column
        angle = 0.5 * math.atan2(
            2.0 * values[p][q], values[q][q] - values[p][p]
        )
        cosine = math.cos(angle)
        sine = math.sin(angle)
        pp = values[p][p]
        qq = values[q][q]
        pq = values[p][q]
        values[p][p] = cosine * cosine * pp - 2 * sine * cosine * pq + sine * sine * qq
        values[q][q] = sine * sine * pp + 2 * sine * cosine * pq + cosine * cosine * qq
        values[p][q] = 0.0
        values[q][p] = 0.0

        for index in range(size):
            if index in (p, q):
                continue
            ip = values[index][p]
            iq = values[index][q]
            values[index][p] = values[p][index] = cosine * ip - sine * iq
            values[index][q] = values[q][index] = sine * ip + cosine * iq

        for index in range(size):
            ip = vectors[index][p]
            iq = vectors[index][q]
            vectors[index][p] = cosine * ip - sine * iq
            vectors[index][q] = sine * ip + cosine * iq
    else:
        raise ArithmeticError("PCA eigenvalue iteration did not converge")

    eigenpairs = sorted(
        ((max(0.0, values[index][index]), index) for index in range(size)),
        key=lambda pair: (-pair[0], pair[1]),
    )
    eigenvalues = [value for value, _ in eigenpairs]
    eigenvectors = [
        [vectors[row][index] for row in range(size)]
        for _, index in eigenpairs
    ]
    for eigenvector in eigenvectors:
        pivot = max(range(size), key=lambda index: (abs(eigenvector[index]), -index))
        if eigenvector[pivot] < 0:
            for index in range(size):
                eigenvector[index] = -eigenvector[index]
    return eigenvalues, eigenvectors


def calculate_pca(prepared: Mapping[str, object]) -> dict[str, object]:
    """Calculate two deterministic PCA score axes and explained variance."""
    documents = prepared.get("documents")
    feature_names = prepared.get("feature_names")
    matrix = prepared.get("matrix")
    feature_set = prepared.get("feature_set")
    if (
        not isinstance(documents, list)
        or not isinstance(feature_names, list)
        or not isinstance(matrix, list)
    ):
        raise ValueError("prepared PCA data must contain documents, features, and matrix")
    if len(documents) != len(matrix) or not matrix:
        raise ValueError("PCA requires a non-empty matrix aligned with documents")
    if any(not isinstance(row, list) or len(row) != len(feature_names) for row in matrix):
        raise ValueError("PCA matrix rows must align with feature names")

    sample_count = len(matrix)
    feature_count = len(feature_names)
    means = [
        sum(float(row[column]) for row in matrix) / sample_count
        for column in range(feature_count)
    ]
    centered = [
        [float(value) - means[column] for column, value in enumerate(row)]
        for row in matrix
    ]
    gram = [
        [
            sum(left * right for left, right in zip(centered[row], centered[column]))
            for column in range(sample_count)
        ]
        for row in range(sample_count)
    ]

    eigenvalues, eigenvectors = _jacobi_eigen(gram)
    total_variance = sum(eigenvalues)
    effective_components = min(COMPONENT_COUNT, max(0, sample_count - 1), feature_count)
    scores: dict[str, list[float]] = {}
    explained_variance = [0.0] * COMPONENT_COUNT

    for component in range(effective_components):
        eigenvalue = eigenvalues[component]
        explained_variance[component] = (
            eigenvalue / total_variance if total_variance else 0.0
        )

    for row, name in enumerate(documents):
        coordinates = []
        for component in range(COMPONENT_COUNT):
            if component < effective_components:
                coordinates.append(
                    eigenvectors[component][row] * math.sqrt(eigenvalues[component])
                )
            else:
                coordinates.append(0.0)
        scores[name] = [round(value, 12) for value in coordinates]

    return {
        "documents": list(documents),
        "feature_set": feature_set,
        "feature_count": feature_count,
        "component_count": effective_components,
        "components": ["PC1", "PC2"],
        "explained_variance_ratio": [
            round(value, 12) for value in explained_variance
        ],
        "scores": scores,
        "standardization": "feature centering only; no per-feature variance scaling",
    }


def analyze_pca(
    stylometry: Mapping[str, object],
    feature_set: str = "function_words",
) -> dict[str, object]:
    """Prepare stylometric vectors and calculate a two-axis PCA."""
    return calculate_pca(prepare_pca_data(stylometry, feature_set))


def render_pca_svg(
    pca: Mapping[str, object],
    output_path: Path = DEFAULT_OUTPUT,
    width: int = 1000,
    height: int = 700,
) -> Path:
    """Write a labeled, standalone SVG scatter plot using only the stdlib."""
    if width < 500 or height < 400:
        raise ValueError("SVG dimensions must be at least 500 by 400 pixels")

    documents = pca.get("documents")
    scores = pca.get("scores")
    ratios = pca.get("explained_variance_ratio")
    if not isinstance(documents, list) or not isinstance(scores, Mapping):
        raise ValueError("PCA result must contain documents and scores")
    if not isinstance(ratios, list) or len(ratios) != COMPONENT_COUNT:
        raise ValueError("PCA result must contain two explained variance ratios")

    points = [(name, scores[name]) for name in documents]
    if any(
        not isinstance(coordinates, list)
        or len(coordinates) != COMPONENT_COUNT
        for _, coordinates in points
    ):
        raise ValueError("Each document must have two PCA coordinates")
    x_values = [float(coordinates[0]) for _, coordinates in points]
    y_values = [float(coordinates[1]) for _, coordinates in points]
    x_min, x_max = min(x_values, default=-1.0), max(x_values, default=1.0)
    y_min, y_max = min(y_values, default=-1.0), max(y_values, default=1.0)
    x_padding = max((x_max - x_min) * 0.15, 1.0)
    y_padding = max((y_max - y_min) * 0.15, 1.0)
    x_min -= x_padding
    x_max += x_padding
    y_min -= y_padding
    y_max += y_padding

    left, right, top, bottom = 100.0, width - 35.0, 90.0, height - 100.0

    def x_position(value: float) -> float:
        return left + (value - x_min) / (x_max - x_min) * (right - left)

    def y_position(value: float) -> float:
        return bottom - (value - y_min) / (y_max - y_min) * (bottom - top)

    x_label = f"PC1 ({float(ratios[0]) * 100:.1f}% erklärte Varianz)"
    y_label = f"PC2 ({float(ratios[1]) * 100:.1f}% erklärte Varianz)"
    elements = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        "<title>Explorative PCA-Visualisierung stilometrischer Merkmale</title>",
        '<rect width="100%" height="100%" fill="white"/>',
        '<g font-family="Arial, sans-serif" fill="#202124">',
        f'<text x="{width / 2:.1f}" y="34" text-anchor="middle" font-size="20">Explorative PCA stilometrischer Textmerkmale</text>',
        f'<text x="{width / 2:.1f}" y="60" text-anchor="middle" font-size="13">Merkmalsblock: {html.escape(str(pca.get("feature_set", "")))}</text>',
        f'<line x1="{left:.1f}" y1="{bottom:.1f}" x2="{right:.1f}" y2="{bottom:.1f}" stroke="#555"/>',
        f'<line x1="{left:.1f}" y1="{top:.1f}" x2="{left:.1f}" y2="{bottom:.1f}" stroke="#555"/>',
    ]
    for tick in range(6):
        fraction = tick / 5
        x_value = x_min + fraction * (x_max - x_min)
        y_value = y_min + fraction * (y_max - y_min)
        x = left + fraction * (right - left)
        y = bottom - fraction * (bottom - top)
        elements.extend(
            (
                f'<line x1="{x:.1f}" y1="{top:.1f}" x2="{x:.1f}" y2="{bottom:.1f}" stroke="#e5e7eb"/>',
                f'<line x1="{left:.1f}" y1="{y:.1f}" x2="{right:.1f}" y2="{y:.1f}" stroke="#e5e7eb"/>',
                f'<text x="{x:.1f}" y="{bottom + 22:.1f}" text-anchor="middle" font-size="11">{x_value:.3g}</text>',
                f'<text x="{left - 10:.1f}" y="{y + 4:.1f}" text-anchor="end" font-size="11">{y_value:.3g}</text>',
            )
        )
    elements.extend(
        (
            f'<text x="{(left + right) / 2:.1f}" y="{height - 28}" text-anchor="middle" font-size="14">{html.escape(x_label)}</text>',
            f'<text x="24" y="{(top + bottom) / 2:.1f}" text-anchor="middle" font-size="14" transform="rotate(-90 24 {(top + bottom) / 2:.1f})">{html.escape(y_label)}</text>',
        )
    )
    palette = ("#1769aa", "#c62828", "#2e7d32", "#8e24aa", "#ef6c00")
    for index, (name, coordinates) in enumerate(points):
        x = x_position(float(coordinates[0]))
        y = y_position(float(coordinates[1]))
        escaped_name = html.escape(str(name))
        color = palette[index % len(palette)]
        elements.extend(
            (
                f'<circle cx="{x:.2f}" cy="{y:.2f}" r="6" fill="{color}" stroke="white" stroke-width="1.5"><title>{escaped_name}</title></circle>',
                f'<text x="{x + 10:.2f}" y="{y - 9:.2f}" font-size="12">{escaped_name}</text>',
            )
        )
    elements.extend(
        (
            f'<text x="{width / 2:.1f}" y="{height - 6}" text-anchor="middle" font-size="11" fill="#555">Explorative Darstellung; keine Aussage über Autorschaft oder historische Zusammenhänge</text>',
            "</g>",
            "</svg>",
        )
    )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(elements) + "\n", encoding="utf-8", newline="\n")
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=PROCESSED_DIR)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--feature-set", choices=FEATURE_SETS, default="function_words")
    args = parser.parse_args()
    stylometry = analyze_corpus(args.input_dir)
    pca = analyze_pca(stylometry, args.feature_set)
    output = render_pca_svg(pca, args.output)
    print(f"Created exploratory PCA plot at {output}")


if __name__ == "__main__":
    main()
