"""Local, reproducible text comparison using lexical and function-word features."""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path
from typing import Mapping

if __package__:
    from .function_words import (
        FUNCTION_WORD_LIST_VERSION,
        FUNCTION_WORD_TO_GROUP,
        function_word_key,
    )
    from .linguistic_analysis import analyze_text, tokenize_words
else:
    from function_words import (
        FUNCTION_WORD_LIST_VERSION,
        FUNCTION_WORD_TO_GROUP,
        function_word_key,
    )
    from linguistic_analysis import analyze_text, tokenize_words


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
DEFAULT_OUTPUT = PROCESSED_DIR / "stylometry.json"
SCHEMA_VERSION = "1.0"
FUNCTION_WORD_FEATURES = tuple(sorted(FUNCTION_WORD_TO_GROUP))
_IDF_METHOD = "log((1 + document_count) / (1 + document_frequency)) + 1"


def _l2_normalize(values: Mapping[str, float]) -> dict[str, float]:
    norm = math.sqrt(sum(value * value for value in values.values()))
    if not norm:
        return {}
    return {term: value / norm for term, value in values.items()}


def _tfidf_vectors(
    documents: Mapping[str, str],
) -> dict[str, dict[str, float]]:
    token_counts = {
        name: Counter(token.lower() for token in tokenize_words(text))
        for name, text in documents.items()
    }
    document_frequency: Counter[str] = Counter()
    for counts in token_counts.values():
        document_frequency.update(counts.keys())

    document_count = len(documents)
    idf = {
        term: math.log((1 + document_count) / (1 + frequency)) + 1
        for term, frequency in document_frequency.items()
    }

    return {
        name: _l2_normalize(
            {term: float(count) * idf[term] for term, count in counts.items()}
        )
        for name, counts in token_counts.items()
    }


def _function_word_vectors(
    documents: Mapping[str, str],
) -> dict[str, dict[str, float]]:
    vectors: dict[str, dict[str, float]] = {}
    for name, text in documents.items():
        words = [token.lower() for token in tokenize_words(text)]
        counts = Counter(
            key for word in words if (key := function_word_key(word)) is not None
        )
        total = len(words)
        vectors[name] = {
            word: counts[word] / total if total else 0.0
            for word in FUNCTION_WORD_FEATURES
        }
    return vectors


def _similarity_matrices(
    vectors: Mapping[str, Mapping[str, float]],
) -> tuple[list[list[float]], list[list[float]]]:
    names = list(vectors)
    similarities: list[list[float]] = []
    distances: list[list[float]] = []

    for left_name in names:
        similarity_row = []
        distance_row = []
        left = vectors[left_name]
        left_norm = math.sqrt(sum(value * value for value in left.values()))
        for right_name in names:
            right = vectors[right_name]
            right_norm = math.sqrt(sum(value * value for value in right.values()))
            dot_product = sum(
                value * right.get(feature, 0.0)
                for feature, value in left.items()
            )
            similarity = (
                dot_product / (left_norm * right_norm)
                if left_norm and right_norm
                else 0.0
            )
            similarity = min(1.0, max(0.0, similarity))
            similarity_row.append(round(similarity, 6))
            distance_row.append(round(1.0 - similarity, 6))
        similarities.append(similarity_row)
        distances.append(distance_row)

    return similarities, distances


def analyze_stylometry(documents: Mapping[str, str]) -> dict[str, object]:
    """Create sparse TF-IDF and function-word vectors with pairwise matrices.

    Document names are sorted so output and matrix axes are reproducible.
    """
    if not documents:
        raise ValueError("At least one document is required")
    if any(not isinstance(name, str) or not name for name in documents):
        raise ValueError("Document names must be non-empty strings")
    if any(not isinstance(text, str) for text in documents.values()):
        raise TypeError("Document texts must be strings")

    names = sorted(documents)
    ordered_documents = {name: documents[name] for name in names}
    tfidf_vectors = _tfidf_vectors(ordered_documents)
    function_word_vectors = _function_word_vectors(ordered_documents)
    tfidf_similarity, tfidf_distance = _similarity_matrices(tfidf_vectors)
    function_similarity, function_distance = _similarity_matrices(
        function_word_vectors
    )

    return {
        "schema_version": SCHEMA_VERSION,
        "configuration": {
            "tokenizer": "linguistic_analysis.tokenize_words; Unicode letters and combining marks, internal apostrophes retained",
            "case_aggregation": "str.lower() for TF-IDF; no spelling normalization, stemming, or lemmatization in TF-IDF features",
            "tfidf": {
                "term_frequency": "raw token count",
                "inverse_document_frequency": _IDF_METHOD,
                "vector_normalization": "L2",
                "vocabulary": "all observed tokens, including function words",
            },
            "function_words": {
                "list_version": FUNCTION_WORD_LIST_VERSION,
                "features": "all entries in the local inventory; long-s maps to s for inventory lookup only; each count divided by document word-token count",
                "similarity_normalization": "cosine similarity",
            },
            "similarity": "cosine; zero vectors have similarity 0, including self-similarity",
            "distance": "1 - cosine similarity",
            "combined_score": None,
        },
        "documents": names,
        "tfidf": {
            "feature_names": sorted(
                {term for vector in tfidf_vectors.values() for term in vector}
            ),
            "vectors": tfidf_vectors,
            "similarity_matrix": tfidf_similarity,
            "distance_matrix": tfidf_distance,
        },
        "function_words": {
            "feature_names": list(FUNCTION_WORD_FEATURES),
            "vectors": function_word_vectors,
            "similarity_matrix": function_similarity,
            "distance_matrix": function_distance,
        },
        "descriptive_features": {
            name: analyze_text(text)
            for name, text in ordered_documents.items()
        },
    }


def analyze_corpus(processed_dir: Path = PROCESSED_DIR) -> dict[str, object]:
    """Analyze every prepared UTF-8 text file in deterministic filename order."""
    processed_dir = Path(processed_dir)
    files = sorted(processed_dir.glob("*.txt"), key=lambda path: path.name)
    if not files:
        raise FileNotFoundError(f"No processed .txt files found in {processed_dir}")
    documents = {
        path.name: path.read_bytes().decode("utf-8")
        for path in files
    }
    return analyze_stylometry(documents)


def save_corpus_analysis(
    processed_dir: Path = PROCESSED_DIR,
    output_path: Path = DEFAULT_OUTPUT,
) -> Path:
    """Write deterministic UTF-8 comparison results as JSON."""
    result = analyze_corpus(processed_dir)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
    output_path.write_text(serialized + "\n", encoding="utf-8", newline="\n")
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=PROCESSED_DIR)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    output = save_corpus_analysis(args.input_dir, args.output)
    print(f"Compared texts; results written to {output}")


if __name__ == "__main__":
    main()
